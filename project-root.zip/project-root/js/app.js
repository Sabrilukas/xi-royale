const state = {
  language: "tr",
  balance: 1000000,
  squadCount: 0,
  minimumPlayers: 6,
  maxPlayers: 16,
  totalPoints: 0,
  squadRatingPoints: 0,
  squadRatingPointsBonus: 0,
  transferOpen: true,
  currentView: "home",
  selectedFormation: "4-4-2",
  selectedPlayers: [],
  selectedSlot: null,
  activePicker: {
    isOpen: false,
    mode: "pick-lineup",
    slotId: null,
    position: null
  },
  lineupSlots: {},
  benchSlots: {
    "bench-1": null,
    "bench-2": null,
    "bench-3": null,
    "bench-4": null,
    "bench-5": null
  },
  matchSimulation: {
    isPlayed: false,
    isProcessing: false,
    lastResult: null,
    history: [],
    readyFeedbackShown: false
  },
  resetConfirmOpen: false,
  rulesModalOpen: false,
  investmentBonusPoints: 0,
  demoInvestmentAmount: 0,
  matchResultModal: {
    isOpen: false
  },
  bonusWheel: {
    targetRank: 3,
    isUnlocked: false,
    isOpen: false,
    isSpinning: false,
    hasSpun: false,
    lastReward: null,
    selectedRewardIndex: null,
    rotation: 0,
    pendingOpen: false
  }
};

const formationLayouts = {
  "4-4-2": [
    { id: "442-fwd-1", position: "FWD", left: 28, top: 14 },
    { id: "442-fwd-2", position: "FWD", left: 72, top: 14 },
    { id: "442-mid-1", position: "MID", left: 11, top: 37 },
    { id: "442-mid-2", position: "MID", left: 37, top: 37 },
    { id: "442-mid-3", position: "MID", left: 63, top: 37 },
    { id: "442-mid-4", position: "MID", left: 89, top: 37 },
    { id: "442-def-1", position: "DEF", left: 11, top: 61 },
    { id: "442-def-2", position: "DEF", left: 37, top: 61 },
    { id: "442-def-3", position: "DEF", left: 63, top: 61 },
    { id: "442-def-4", position: "DEF", left: 89, top: 61 },
    { id: "442-gk-1",  position: "GK",  left: 50, top: 84 }
  ],
  "3-5-2": [
    { id: "352-fwd-1", position: "FWD", left: 28, top: 14 },
    { id: "352-fwd-2", position: "FWD", left: 72, top: 14 },
    { id: "352-mid-1", position: "MID", left: 9,  top: 38 },
    { id: "352-mid-2", position: "MID", left: 28, top: 38 },
    { id: "352-mid-3", position: "MID", left: 50, top: 38 },
    { id: "352-mid-4", position: "MID", left: 72, top: 38 },
    { id: "352-mid-5", position: "MID", left: 91, top: 38 },
    { id: "352-def-1", position: "DEF", left: 22, top: 62 },
    { id: "352-def-2", position: "DEF", left: 50, top: 62 },
    { id: "352-def-3", position: "DEF", left: 78, top: 62 },
    { id: "352-gk-1",  position: "GK",  left: 50, top: 84 }
  ],
  "4-3-3": [
    { id: "433-fwd-1", position: "FWD", left: 18, top: 14 },
    { id: "433-fwd-2", position: "FWD", left: 50, top: 14 },
    { id: "433-fwd-3", position: "FWD", left: 82, top: 14 },
    { id: "433-mid-1", position: "MID", left: 18, top: 40 },
    { id: "433-mid-2", position: "MID", left: 50, top: 40 },
    { id: "433-mid-3", position: "MID", left: 82, top: 40 },
    { id: "433-def-1", position: "DEF", left: 11, top: 62 },
    { id: "433-def-2", position: "DEF", left: 37, top: 62 },
    { id: "433-def-3", position: "DEF", left: 63, top: 62 },
    { id: "433-def-4", position: "DEF", left: 89, top: 62 },
    { id: "433-gk-1",  position: "GK",  left: 50, top: 84 }
  ]
};

const demoPlayers = [
  // ── Existing players (ids 1–14) — do not modify ──────────
  { id: 1,  name: "Kylian M.",   country: "France",      price: 91000, rating: 9.1, position: "FWD" },
  { id: 2,  name: "Jude B.",     country: "England",     price: 88000, rating: 8.8, position: "MID" },
  { id: 3,  name: "Alisson B.",  country: "Brazil",      price: 84000, rating: 8.4, position: "GK"  },
  { id: 4,  name: "Harry K.",    country: "England",     price: 87000, rating: 8.7, position: "FWD" },
  { id: 5,  name: "Vinicius J.", country: "Brazil",      price: 90000, rating: 9.0, position: "FWD" },
  { id: 6,  name: "Kevin D.",    country: "Belgium",     price: 86000, rating: 8.6, position: "MID" },
  { id: 7,  name: "Luka M.",     country: "Croatia",     price: 78000, rating: 8.1, position: "MID" },
  { id: 8,  name: "Virgil V.",   country: "Netherlands", price: 82000, rating: 8.3, position: "DEF" },
  { id: 9,  name: "Achraf H.",   country: "Morocco",     price: 76000, rating: 7.9, position: "DEF" },
  { id: 10, name: "Theo H.",     country: "France",      price: 79000, rating: 8.0, position: "DEF" },
  { id: 11, name: "Emiliano M.", country: "Argentina",   price: 80000, rating: 8.2, position: "GK"  },
  { id: 12, name: "Ruben D.",    country: "Portugal",    price: 81000, rating: 8.2, position: "DEF" },
  { id: 13, name: "Fede V.",     country: "Uruguay",     price: 79000, rating: 8.1, position: "MID" },
  { id: 14, name: "Pedri G.",    country: "Spain",       price: 77000, rating: 8.0, position: "MID" },
  // ── New players (ids 15–28) ──────────────────────────────
  { id: 15, name: "Bruno F.",    country: "Portugal",    price: 83000, rating: 8.3, position: "MID" },
  { id: 16, name: "Rodri H.",    country: "Spain",       price: 89000, rating: 8.9, position: "MID" },
  { id: 17, name: "Bukayo S.",   country: "England",     price: 85000, rating: 8.4, position: "FWD" },
  { id: 18, name: "Antoine G.",  country: "France",      price: 81000, rating: 8.2, position: "FWD" },
  { id: 19, name: "Marquinhos", country: "Brazil",      price: 80000, rating: 8.1, position: "DEF" },
  { id: 20, name: "Pau T.",      country: "Spain",       price: 75000, rating: 7.8, position: "DEF" },
  { id: 21, name: "Joao C.",     country: "Portugal",    price: 78000, rating: 8.0, position: "DEF" },
  { id: 22, name: "Yassine B.",  country: "Morocco",     price: 76000, rating: 7.9, position: "GK"  },
  { id: 23, name: "Thibaut C.",  country: "Belgium",     price: 85000, rating: 8.5, position: "GK"  },
  { id: 24, name: "Lautaro M.",  country: "Argentina",   price: 82000, rating: 8.3, position: "FWD" },
  { id: 25, name: "Cody G.",     country: "Netherlands", price: 77000, rating: 7.8, position: "FWD" },
  { id: 26, name: "Enzo F.",     country: "Argentina",   price: 79000, rating: 8.0, position: "MID" },
  { id: 27, name: "Sofyan A.",   country: "Morocco",     price: 74000, rating: 7.7, position: "MID" },
  { id: 28, name: "Jules K.",    country: "France",      price: 77000, rating: 7.9, position: "DEF" }
];

// Demo-only bonus wheel rewards. Random selection used in spinBonusWheel().
const wheelRewards = [
  { label: "+50 Puan",       points: 50,  squadPower: 0,  type: "points"     },
  { label: "+75 Puan",       points: 75,  squadPower: 0,  type: "points"     },
  { label: "+100 Puan",      points: 100, squadPower: 0,  type: "points"     },
  { label: "+150 Puan",      points: 150, squadPower: 0,  type: "points"     },
  { label: "+10 Kadro Gücü", points: 0,   squadPower: 10, type: "squadPower" },
  { label: "Bonus Yok",      points: 0,   squadPower: 0,  type: "empty"      }
];

// ─────────────────────────────────────────────────────────────
// i18n — Turkish / English translation dictionary + helpers
// ─────────────────────────────────────────────────────────────
const translations = {
  tr: {
    // Brand & header
    brandKicker: "World Cup Fantasy",
    balance: "Bakiye",
    virtualBalance: "Sanal Bakiye",

    // Hero
    promoBadge: "Turnuva Oyunu",
    homeHeroTitle1: "Kadronu Kur,",
    homeHeroTitle2: "Zirveye Oyna",
    homeHeroTitleHtml: "Kadronu Kur,<span>Zirveye Oyna</span>",
    homeHeroCopy: "Dünya Kupası yıldızlarını sanal bütçenle seç. Rating puanlarıyla leaderboard'da yüksel.",
    jackpotTarget: "Jackpot Hedefi",
    jackpotValue: "50,000 Puan",
    avgLabel: "AVG",
    buildTeam: "Kadromu Kur",

    // Cash Vault
    cashVault: "Ana Kasa",
    investmentBonus: "Yatırım Bonusu",
    demo: "Demo",
    totalInvested: "Toplam Yatırım",
    bonusPointsLabel: "Bonus Puan",
    noInvestmentYet: "Henüz yatırım yapılmadı",
    invest100k: "+100K Sanal Yatırım",
    invest500k: "+500K Sanal Yatırım",
    vault100kRule: "100K Sanal",
    vault500kRule: "500K Sanal",
    vault100kReward: "+100 Puan",
    vault500kReward: "+500 Puan",
    vaultNote: "Demo özellik — gerçek ödeme, cüzdan veya para yatırma işlemi içermez.",
    vaultLockedNote: "Yatırım dönemi kapandı. Yeni Tur ile sıfırlanır.",

    // Challenge card
    todayChallenge: "Today Challenge",
    worldCupChallenge: "Dünya Kupası Fantasy Challenge",
    rules: "Kurallar",
    minimum: "Minimum",
    players6: "6 Oyuncu",
    target: "Hedef",
    targetPoints: "50,000 Puan",
    status: "Durum",
    transferOpen: "Transfer Açık",
    transferClosed: "Transfer Kapalı",
    lineupGo: "Line-up'a Git",

    // How It Works
    howItWorks: "How It Works",
    howSteps: "4 Adımda Oyna",
    step1Title: "Oyuncu Seç",
    step1Desc: "Sanal bütçenle yıldızları kadrona ekle.",
    step2Title: "Kadroyu Kur",
    step2Desc: "İlk 11 ve 5 yedek slotunu doldur.",
    step3Title: "Maçı Oynat",
    step3Desc: "Minimum 6 oyuncuyla demo simülasyonu başlat.",
    step4Title: "Sıralamada Yüksel",
    step4Desc: "Rating puanların leaderboard'a yansır.",

    // Info panels
    market: "Market",
    transferWindow: "Transfer Window",
    open: "Açık",
    closed: "Kapalı",
    transferCopyOpen: "Günün ilk maçı başlamadan önce transfer yapabilirsin. İlk maç başladıktan sonra transfer kilitlenir.",
    transferCopyClosed: "Demo maç sonrası transfer dönemi kapandı. Yeni kadro kurmak için Kadroyu Sıfırla kullan.",
    leaderboard: "Leaderboard",
    ranking: "Sıralama",
    leaderboardInfo: "Maç sonu oyuncu ratingleri toplam puanına eklenir. 8.5+ rating alan kaybeden takım oyuncuları boost kazanır.",

    // Nav
    home: "Home",
    lineup: "Line-up",
    board: "Board",

    // Quick stats
    squad: "Kadro",
    squadPower: "Kadro Gücü",
    transfer: "Transfer",
    matchPoints: "Maç Puanı",

    // Squad progress
    squadProgress: "Squad Progress",
    squadCompletion: "Kadro Tamamlama",
    progressMin: "6 Min",
    progressXI: "11 XI",
    progressFull: "16 Full",
    squadDone: "Kadro tamamlandı.",
    squadReadyXI: "İlk 11 hazır, bench'i güçlendir.",
    squadReadyDemo: "Demo maç oynatılabilir, ilk 11'i tamamla.",
    squadNeedMore: (n) => `Maç puanı için ${n} oyuncu daha seç.`,
    squadStart: (n) => `Maç puanı için ${n} oyuncu daha seç.`,

    // Action row
    autoBuild: "Otomatik Kadro Kur",
    resetSquad: "Kadroyu Sıfırla",

    // Lineup panel
    lineupHeader: "Line-up",
    teamSquad: "Takım Kadron",
    bench: "Bench",
    benchSubstitutes: "Yedek Kulübesi",
    lineupWarning: "Minimum 6 oyuncu seçmeden maç puanı kazanamazsın.",
    lineupReady: "Minimum tamamlandı. Demo maç puanı kazanabilirsin.",

    // Match panel
    matchSimulation: "Match Simulation",
    earnPoints: "Puan Kazan",
    matchStatusReady: "Hazır",
    matchStatusLocked: "Kilitli",
    matchStatusSim: "Simülasyon",
    matchStatusDone: "Tamamlandı",
    playDemoMatch: "Demo Maçı Oynat",
    players6Required: "6 Oyuncu Gerekli",
    simulating: "Simülasyon...",
    matchCopyReady: "Demo maç puanı oyuncu ratinglerine göre hesaplanır. 8.5+ performanslı oyuncular booster kazanır.",
    matchCopyDone: "Maç tamamlandı. Puanlar leaderboard'a yansıdı.",
    matchCopySim: "Demo maç simülasyonu çalışıyor...",
    matchCopyLocked: (n) => `${n} oyuncu daha ekle, maç puanı kazanmaya başla.`,
    matchCopyLockedStart: (min) => `Maç puanı kazanmak için en az ${min} oyuncu seçmelisin.`,
    bonusAvg: "Puan",
    bonusAvgValue: "Rating",
    boosterRule: "Booster",
    boosterRuleValue: "8.5+",
    squadReadyTitle: "Kadron Hazır",
    squadReadyDesc: "Demo maç simülasyonunu başlat ve leaderboard'da yüksel.",
    matchDisclaimer: "Demo simülasyon. Gerçek bahis, ödeme veya para ödülü yoktur.",
    matchCompletedShort: "Maç Tamamlandı",
    totalPointsShort: "toplam puan",
    rankChangeLabel: "Rank Change",
    avgRatingLabel: "AVG Rating",
    viewResultAgain: "Sonucu Tekrar Gör",
    startNewRound: "Yeni Tur Başlat",

    // Match Result Modal
    matchResultKicker: "MAÇ SONUCU",
    matchFinished: "MAÇ TAMAMLANDI!",
    matchResultHeroCopy: "Harika performans! Tüm puanların hesaplandı.",
    basePointsLabel: "Maç Puanı",
    basePointsDesc: "Oyuncularının rating performansı",
    boosterPointsLabel: "Booster Points",
    boosterNone: "Bu maçta booster yok",
    cashVaultBonus: "Ana Kasa Bonusu",
    cashVaultBonusDesc: "Sanal yatırım bonusu",
    noInvestment: "Yatırım yapılmadı",
    wheelBonus: "Çark Bonusu",
    wheelBonusDesc: "Bonus çarkından kazandığın puan",
    wheelBonusSquadPowerDesc: (n) => `+${n} Kadro Gücü (puan değil)`,
    wheelBonusEmpty: "Bu tur çarktan puan çıkmadı",
    grandTotal: "TOPLAM KAZANÇ",
    points: "puan",
    rankAdvanceText: (n) => `Leaderboard'da <strong>+${n} sıra</strong> yükseldin`,
    vaultNoteResult: "Ana Kasa bonusun sanal yatırımından geldi ve toplam puanına eklendi.",
    viewOnBoard: "SONUCU BOARD'DA GÖR",
    close: "Kapat",

    // Board
    tournament: "Tournament",
    worldCupLeague: "Dünya Kupası Ligi",
    boardHeroCopyEmpty: "Demo turnuva hazır. Maç oynamadan önce sıralaman kilitli durumda.",
    boardHeroCopyDefault: "Demo turnuva sıralaması. Maç simülasyonu sonrası yerin ve puanın güncellenir.",
    boardHeroCopyPodium: "Podiumdasın. Liderlik için challenge'a devam et.",
    boardHeroCopyClose: "Podiuma yaklaşıyorsun. Daha güçlü kadro kur.",
    boardHeroCopyFar: "Daha yüksek ratingli oyuncular ile sıralamada yüksel.",
    boardHeroCopyVaultNote: "Toplam puana maç sonucu, booster ve Ana Kasa bonusu dahildir.",
    totalPointsBoardLabel: "Toplam Puan",
    rankChangeShort: "Son Rank Değişimi",
    avgRating: "Ortalama Rating",
    pointBreakdown: "Puan Breakdown",
    breakdownEmpty: "Demo maç sonrası puan breakdown burada görünür.",
    breakdownMatchPoints: "Maç Puanı",
    breakdownTotalSub: "Leaderboard sıralamana yansıyan toplam puan.",
    podium: "Podium",
    top3: "İlk 3 Takım",
    tournamentRanking: "Turnuva Sıralaması",
    matchHistory: "Match History",
    lastResults: "Son Sonuçlar",
    historyEmpty: "Demo maç oynadıktan sonra son sonuçların burada görünür.",
    lastMatch: "Son Maç",
    previousMatch: (n) => `${n}. Önceki Maç`,
    avg: "AVG",
    kadro: "Kadro",
    rank: "Rank",
    boost: "Boost",
    kasa: "Kasa",
    waiting: "Bekleniyor",
    waitingForMatch: "Maç bekleniyor",
    pts: "pts",
    you: "Sen",

    // Scout
    scout: "Scout",
    featuredPlayers: "Öne Çıkan Oyuncular",
    scoutCopy: "Kadro kurmak için saha üzerindeki pozisyonlara dokun. Otomatik kurmak için yukarıdaki butonu kullan.",
    inSquad: "Kadroda",
    scoutBadge: "Scout",

    // Picker
    positionPick: "Position Pick",
    selectPlayer: "Oyuncu Seç",
    position: "Pozisyon",
    cannotReselect: "Tekrar seçim yapılamaz",
    pickerFooter: "Demo fantasy MVP • Gerçek para içermez",
    pickerCurrent: "Mevcut",
    pickerTaken: "Alındı",
    pickerClosed: "Kapalı",
    pickerInsufficient: "Yetersiz",
    pickerBuy: "Al",
    pickerTransferClosed: "Transfer kapalı",

    // Reset modal
    resetTitle: "Kadroyu Sıfırla?",
    resetDescription: "Tüm oyuncular kaldırılır, bakiye $1,000,000 olur ve maç sonucu temizlenir.",
    cancel: "Vazgeç",
    confirmReset: "Sıfırla",

    // Rules modal
    rulesTitle: "XI Royale Nasıl Oynanır?",
    rule1Title: "Sanal Bütçe",
    rule1Desc: "$1,000,000 sanal bakiye ile başlarsın. Gerçek para içermez.",
    rule2Title: "Kadro",
    rule2Desc: "11 saha oyuncusu + 5 yedek ile 16 kişilik kadro hedeflenir.",
    rule3Title: "Minimum Oyuncu",
    rule3Desc: "Demo maç oynatmak için en az 6 oyuncu seçmelisin.",
    rule4Title: "Kadro Gücü",
    rule4Desc: "Oyuncu ratingleri rating × 10 mantığıyla kadro gücüne eklenir.",
    rule5Title: "Maç Puanı",
    rule5Desc: "Demo maç puanı oyuncu ratinglerine göre hesaplanır. 8.5+ performanslı oyuncular +15 booster kazanır.",
    rule6Title: "Rating Booster",
    rule6Desc: "Demo simülasyonda 8.5+ performans rating alan ve kaybeden takımda sayılan oyuncular +15 boost kazanabilir.",
    rule7Title: "Transfer Kilidi",
    rule7Desc: "Demo maç oynandıktan sonra transfer dönemi kapanır. Yeni kadro için Kadroyu Sıfırla kullanılır.",
    rule8Title: "Demo Uyarısı",
    rule8Desc: "Bu MVP gerçek bahis, ödeme, cüzdan veya para ödülü içermez.",

    // Bonus Wheel
    bonusWheelKicker: "Bonus Wheel",
    bonusWheelTitle: "İlk 3 Bonusu Açıldı",
    bonusWheelCloseAria: "Bonus çarkı penceresini kapat",
    wheelSpin: "Çarkı Çevir",
    wheelSpinning: "Çark dönüyor...",
    wheelSpun: "Çevrildi",
    wheelStatusUnlocked: "Çarkı çevir, ödülünü kazan.",
    wheelStatusSpinning: "Sonuç belirleniyor...",
    wheelCongrats: (label) => `Tebrikler! ${label} kazandın.`,
    wheelSquadPowerMsg: (n) => `+${n} Kadro Gücü eklendi.`,
    wheelEmptyMsg: "Bu tur bonus çıkmadı.",
    wheelDisclaimer: "Demo bonus — gerçek para veya ödül içermez.",
    wheelSeeResult: "Sonucu Gör",
    wheelLabelPoints: "Puan",
    wheelLabelPower: "Güç",
    wheelLabelNone: "Bonus Yok",

    // Budget impact labels
    noDiff: "Fark yok",
    budgetExtra: (amount) => `Ekstra: ${amount}`,
    budgetRefund: (amount) => `İade: ${amount}`,
    budgetRemaining: (amount) => `Kalan: ${amount}`,
    budgetInsufficient: "Yetersiz bakiye",

    // Bonus breakdown prefixes
    bonusLabelSquad: "Kadro",
    bonusLabelRating: "Rating",
    bonusLabelDemo: "Demo",

    // Bench rendering
    benchSlotLabel: "YEDEK",
    emptyBenchSlotAria: "Boş yedek slotu",
    benchSlotAriaFilled: (name, country) => `${name}, ${country}, yedek`,

    // Picker modal labels
    benchPickerKicker: "Yedek Seçim",
    benchPickerTitle: "Yedek Oyuncu Seç",
    pickerPositionLabel: (pos) => `Slot: ${pos}`,
    pickerBenchSlotLabel: "Slot: YEDEK",
    pickerBalanceLabel: (amount) => `Bakiye: ${amount}`,
    pickerPointsLabel: (pts) => `Puan: ${pts}`,
    pickerCurrentNote: "Mevcut oyuncu hariç tekrar seçim yok",
    pickerPositionTitle: (pos) => `${pos} Oyuncu Seç`,

    // Slot manager
    slotManagementKicker: "Slot Management",
    statCountry: "Ülke",
    statPrice: "Fiyat",
    statSquadPts: "Kadro Puanı",
    statCurrentBalance: "Mevcut Bakiye",
    slotActionReplace: "Oyuncuyu Değiştir",
    slotActionRemove: "Oyuncuyu Kaldır",

    // Player action feedback (dynamic)
    fbPlayerAlreadyInSquad: (name) => `${name} zaten kadroda.`,
    fbPlayerAdded: (name) => `${name} kadroya eklendi. Bakiye güncellendi.`,
    fbPlayerRemoved: (name) => `${name} kadrodan çıkarıldı. Bakiye güncellendi.`,
    fbPlayerAlreadyInSlot: (name) => `${name} zaten bu slotta.`,
    fbPlayerAlreadyInSquadElsewhere: (name) => `${name} zaten kadroda.`,
    slotPositionError: (pos) => `${pos} slotuna sadece ${pos} oyuncusu seçilebilir.`,

    // Feedback messages
    fbNotEnoughPlayers: "Minimum 6 oyuncu seçmeden maç puanı kazanamazsın.",
    fbMatchDone: "Demo maç tamamlandı. Transfer dönemi kapandı. Yeni kadro için reset kullan.",
    fbRoundDone: "Bu tur tamamlandı. Yeni maç için Yeni Tur Başlat.",
    fbSquadReset: "Kadro sıfırlandı. Yeni takım kurmaya başlayabilirsin.",
    fbAutoBuilt: "Otomatik kadro kuruldu. Demo maç oynatılabilir.",
    fbTransferClosed: "Transfer dönemi kapalı. Yeni kadro için reset kullan.",
    fbVaultClosed: "Yatırım dönemi kapandı. Yeni Tur ile sıfırlanır.",
    fbVaultAdded: (amount, pts) => `+${amount} sanal yatırım eklendi. +${pts} maç puanı bonus kazandın.`,
    fbWheelLocked: "Bonus çarkı için leaderboard'da ilk 3'e girmelisin.",
    fbWheelAlreadySpun: "Bu tur bonus çarkı zaten çevrildi.",
    fbWheelPoints: (label) => `Bonus çarkı: ${label} maç puanına eklendi.`,
    fbWheelPower: "Bonus çarkı: +10 Kadro Gücü eklendi.",
    fbWheelEmpty: "Bonus çarkı: Bu tur bonus çıkmadı.",
    fbFormationChosen: (name) => `${name} formasyonu seçildi.`,
    fbFormationRefund: (names) => `${names} için bench dolu olduğu için bakiye iade edildi.`,
    fbFormationBench: (names) => `${names} yeni formasyonda bench'e taşındı.`,
    fbPlayerSwap: (oldName, newName) => `${oldName} yerine ${newName} seçildi. Bakiye güncellendi.`,
    fbInsufficient: (amount) => `Bakiye yetersiz. Değişim için ${amount} gerekli.`,
    fbSlotGone: "Bu slot artık mevcut formasyonda yok.",
    fbSlotFull: "Bu slot dolu. Başka bir boş slot seç.",
    fbBenchSlotInvalid: "Geçerli bir bench slotu seç.",
    fbBenchSlotFull: "Bu bench slotu dolu. Başka bir boş slot seç.",
    fbSquadNoSlot: "Kadroda boş slot yok.",
    fbSquadFull: "Kadro limiti dolu.",
    fbBalanceLow: "Bakiye yetersiz.",
    fbSlotEmpty: "Bu slot zaten boş.",
    fbSwapInvalid: "Değişim için geçerli bir slot seç."
  },

  en: {
    brandKicker: "World Cup Fantasy",
    balance: "Balance",
    virtualBalance: "Virtual Balance",

    promoBadge: "Tournament Game",
    homeHeroTitle1: "Build Your Squad,",
    homeHeroTitle2: "Play for the Top",
    homeHeroTitleHtml: "Build Your Squad,<span>Play for the Top</span>",
    homeHeroCopy: "Pick World Cup stars with your virtual budget. Climb the leaderboard with rating points.",
    jackpotTarget: "Jackpot Target",
    jackpotValue: "50,000 Points",
    avgLabel: "AVG",
    buildTeam: "Build Squad",

    cashVault: "Cash Vault",
    investmentBonus: "Investment Bonus",
    demo: "Demo",
    totalInvested: "Total Invested",
    bonusPointsLabel: "Bonus Points",
    noInvestmentYet: "No investment yet",
    invest100k: "+100K Virtual Investment",
    invest500k: "+500K Virtual Investment",
    vault100kRule: "100K Virtual",
    vault500kRule: "500K Virtual",
    vault100kReward: "+100 Points",
    vault500kReward: "+500 Points",
    vaultNote: "Demo feature — no real payment, wallet or cash deposit is included.",
    vaultLockedNote: "Investment period closed. Reset with New Round.",

    todayChallenge: "Today Challenge",
    worldCupChallenge: "World Cup Fantasy Challenge",
    rules: "Rules",
    minimum: "Minimum",
    players6: "6 Players",
    target: "Target",
    targetPoints: "50,000 Points",
    status: "Status",
    transferOpen: "Transfer Open",
    transferClosed: "Transfer Closed",
    lineupGo: "Go to Line-up",

    howItWorks: "How It Works",
    howSteps: "Play in 4 Steps",
    step1Title: "Pick Players",
    step1Desc: "Add stars to your squad with your virtual budget.",
    step2Title: "Build the Squad",
    step2Desc: "Fill the starting XI and 5 bench slots.",
    step3Title: "Play the Match",
    step3Desc: "Start the demo simulation with at least 6 players.",
    step4Title: "Climb the Ranking",
    step4Desc: "Your rating points reflect on the leaderboard.",

    market: "Market",
    transferWindow: "Transfer Window",
    open: "Open",
    closed: "Closed",
    transferCopyOpen: "You can transfer before the first match of the day. Transfers lock once the first match starts.",
    transferCopyClosed: "Transfer period closed after the demo match. Use Reset Squad to start fresh.",
    leaderboard: "Leaderboard",
    ranking: "Ranking",
    leaderboardInfo: "Player ratings add to your total points after each match. Losing-team players with 8.5+ rating earn a boost.",

    home: "Home",
    lineup: "Line-up",
    board: "Board",

    squad: "Squad",
    squadPower: "Squad Power",
    transfer: "Transfer",
    matchPoints: "Match Points",

    squadProgress: "Squad Progress",
    squadCompletion: "Squad Completion",
    progressMin: "6 Min",
    progressXI: "11 XI",
    progressFull: "16 Full",
    squadDone: "Squad completed.",
    squadReadyXI: "Starting XI ready — strengthen the bench.",
    squadReadyDemo: "Demo match playable — finish your starting XI.",
    squadNeedMore: (n) => `Pick ${n} more player(s) to earn match points.`,
    squadStart: (n) => `Pick ${n} more player(s) to earn match points.`,

    autoBuild: "Auto Build Squad",
    resetSquad: "Reset Squad",

    lineupHeader: "Line-up",
    teamSquad: "Your Squad",
    bench: "Bench",
    benchSubstitutes: "Substitutes",
    lineupWarning: "You need at least 6 players to earn match points.",
    lineupReady: "Minimum reached. Demo match points unlocked.",

    matchSimulation: "Match Simulation",
    earnPoints: "Earn Points",
    matchStatusReady: "Ready",
    matchStatusLocked: "Locked",
    matchStatusSim: "Simulating",
    matchStatusDone: "Completed",
    playDemoMatch: "Play Demo Match",
    players6Required: "6 Players Required",
    simulating: "Simulating...",
    matchCopyReady: "Demo match points are based on player ratings. Players with 8.5+ performance earn a booster.",
    matchCopyDone: "Match completed. Points reflected on the leaderboard.",
    matchCopySim: "Demo match simulation running...",
    matchCopyLocked: (n) => `Add ${n} more player(s) to earn match points.`,
    matchCopyLockedStart: (min) => `Pick at least ${min} players to earn match points.`,
    bonusAvg: "Score",
    bonusAvgValue: "Rating",
    boosterRule: "Booster",
    boosterRuleValue: "8.5+",
    squadReadyTitle: "Squad Ready",
    squadReadyDesc: "Start the demo simulation and climb the leaderboard.",
    matchDisclaimer: "Demo simulation. No real betting, payment or prize.",
    matchCompletedShort: "Match Completed",
    totalPointsShort: "total points",
    rankChangeLabel: "Rank Change",
    avgRatingLabel: "AVG Rating",
    viewResultAgain: "View Result Again",
    startNewRound: "Start New Round",

    matchResultKicker: "MATCH RESULT",
    matchFinished: "MATCH COMPLETED!",
    matchResultHeroCopy: "Great performance! All your points have been calculated.",
    basePointsLabel: "Match Points",
    basePointsDesc: "Your players' rating performance",
    boosterPointsLabel: "Booster Points",
    boosterNone: "No boosters in this match",
    cashVaultBonus: "Cash Vault Bonus",
    cashVaultBonusDesc: "Virtual investment bonus",
    noInvestment: "No investment made",
    wheelBonus: "Wheel Bonus",
    wheelBonusDesc: "Points won from the bonus wheel",
    wheelBonusSquadPowerDesc: (n) => `+${n} Squad Power (not points)`,
    wheelBonusEmpty: "No points from the wheel this round",
    grandTotal: "TOTAL EARNED",
    points: "points",
    rankAdvanceText: (n) => `You climbed <strong>+${n} ranks</strong> on the leaderboard`,
    vaultNoteResult: "Your Cash Vault bonus came from your virtual investment and was added to your total points.",
    viewOnBoard: "VIEW ON BOARD",
    close: "Close",

    tournament: "Tournament",
    worldCupLeague: "World Cup League",
    boardHeroCopyEmpty: "Demo tournament ready. Your rank is locked until you play a match.",
    boardHeroCopyDefault: "Demo tournament ranking. Your position and points update after the match simulation.",
    boardHeroCopyPodium: "You're on the podium. Keep going to take the lead.",
    boardHeroCopyClose: "You're close to the podium. Build a stronger squad.",
    boardHeroCopyFar: "Climb higher by picking players with stronger ratings.",
    boardHeroCopyVaultNote: "Total points include match result, booster and Cash Vault bonus.",
    totalPointsBoardLabel: "Total Points",
    rankChangeShort: "Last Rank Change",
    avgRating: "Avg Rating",
    pointBreakdown: "Point Breakdown",
    breakdownEmpty: "Your point breakdown appears here after the demo match.",
    breakdownMatchPoints: "Match Points",
    breakdownTotalSub: "Total points reflected on the leaderboard.",
    podium: "Podium",
    top3: "Top 3 Teams",
    tournamentRanking: "Tournament Ranking",
    matchHistory: "Match History",
    lastResults: "Recent Results",
    historyEmpty: "Your recent results appear here after playing a demo match.",
    lastMatch: "Last Match",
    previousMatch: (n) => `${n}. Previous Match`,
    avg: "AVG",
    kadro: "Squad",
    rank: "Rank",
    boost: "Boost",
    kasa: "Vault",
    waiting: "Waiting",
    waitingForMatch: "Waiting for match",
    pts: "pts",
    you: "You",

    scout: "Scout",
    featuredPlayers: "Featured Players",
    scoutCopy: "Tap a position on the pitch to build your squad. Or use the button above for auto build.",
    inSquad: "In Squad",
    scoutBadge: "Scout",

    positionPick: "Position Pick",
    selectPlayer: "Select Player",
    position: "Position",
    cannotReselect: "Cannot reselect",
    pickerFooter: "Demo fantasy MVP • No real money",
    pickerCurrent: "Current",
    pickerTaken: "Taken",
    pickerClosed: "Closed",
    pickerInsufficient: "Insufficient",
    pickerBuy: "Buy",
    pickerTransferClosed: "Transfer closed",

    resetTitle: "Reset Squad?",
    resetDescription: "All players will be removed, balance returns to $1,000,000 and match result is cleared.",
    cancel: "Cancel",
    confirmReset: "Reset",

    rulesTitle: "How to Play XI Royale?",
    rule1Title: "Virtual Budget",
    rule1Desc: "You start with $1,000,000 virtual balance. No real money involved.",
    rule2Title: "Squad",
    rule2Desc: "Target a 16-player squad: 11 starters + 5 substitutes.",
    rule3Title: "Minimum Players",
    rule3Desc: "You must pick at least 6 players to play the demo match.",
    rule4Title: "Squad Power",
    rule4Desc: "Player ratings are added to Squad Power using rating × 10.",
    rule5Title: "Match Points",
    rule5Desc: "Demo match points are based on player ratings. Players with 8.5+ performance earn a +15 booster.",
    rule6Title: "Rating Booster",
    rule6Desc: "Players with 8.5+ performance on the losing side may earn a +15 boost in the demo simulation.",
    rule7Title: "Transfer Lock",
    rule7Desc: "Transfer period closes after the demo match. Use Reset Squad to start fresh.",
    rule8Title: "Demo Notice",
    rule8Desc: "This MVP does not include real betting, payment, wallet or cash prize.",

    bonusWheelKicker: "Bonus Wheel",
    bonusWheelTitle: "Top 3 Bonus Unlocked",
    bonusWheelCloseAria: "Close bonus wheel",
    wheelSpin: "Spin Wheel",
    wheelSpinning: "Wheel spinning...",
    wheelSpun: "Spun",
    wheelStatusUnlocked: "Spin the wheel, win your reward.",
    wheelStatusSpinning: "Determining result...",
    wheelCongrats: (label) => `Congrats! You won ${label}.`,
    wheelSquadPowerMsg: (n) => `+${n} Squad Power added.`,
    wheelEmptyMsg: "No bonus this round.",
    wheelDisclaimer: "Demo bonus — no real money or prize.",
    wheelSeeResult: "See Result",
    wheelLabelPoints: "Pts",
    wheelLabelPower: "Power",
    wheelLabelNone: "No Bonus",

    // Budget impact labels
    noDiff: "No change",
    budgetExtra: (amount) => `Extra: ${amount}`,
    budgetRefund: (amount) => `Refund: ${amount}`,
    budgetRemaining: (amount) => `Remaining: ${amount}`,
    budgetInsufficient: "Insufficient",

    // Bonus breakdown prefixes
    bonusLabelSquad: "Squad",
    bonusLabelRating: "Rating",
    bonusLabelDemo: "Demo",

    // Bench rendering
    benchSlotLabel: "BENCH",
    emptyBenchSlotAria: "Empty bench slot",
    benchSlotAriaFilled: (name, country) => `${name}, ${country}, bench`,

    // Picker modal labels
    benchPickerKicker: "Bench Pick",
    benchPickerTitle: "Pick Bench Player",
    pickerPositionLabel: (pos) => `Slot: ${pos}`,
    pickerBenchSlotLabel: "Slot: BENCH",
    pickerBalanceLabel: (amount) => `Balance: ${amount}`,
    pickerPointsLabel: (pts) => `Points: ${pts}`,
    pickerCurrentNote: "Cannot reselect except current player",
    pickerPositionTitle: (pos) => `Pick ${pos} Player`,

    // Slot manager
    slotManagementKicker: "Slot Management",
    statCountry: "Country",
    statPrice: "Price",
    statSquadPts: "Squad Points",
    statCurrentBalance: "Current Balance",
    slotActionReplace: "Replace Player",
    slotActionRemove: "Remove Player",

    // Player action feedback (dynamic)
    fbPlayerAlreadyInSquad: (name) => `${name} is already in your squad.`,
    fbPlayerAdded: (name) => `${name} added to squad. Balance updated.`,
    fbPlayerRemoved: (name) => `${name} removed from squad. Balance updated.`,
    fbPlayerAlreadyInSlot: (name) => `${name} is already in this slot.`,
    fbPlayerAlreadyInSquadElsewhere: (name) => `${name} is already in your squad.`,
    slotPositionError: (pos) => `This slot only accepts ${pos} players.`,

    fbNotEnoughPlayers: "You need at least 6 players to earn match points.",
    fbMatchDone: "Demo match completed. Transfer period closed. Use Reset for a new squad.",
    fbRoundDone: "This round is over. Use Start New Round for a new match.",
    fbSquadReset: "Squad reset. You can start building a new team.",
    fbAutoBuilt: "Auto squad built. Demo match playable.",
    fbTransferClosed: "Transfer period closed. Use Reset for a new squad.",
    fbVaultClosed: "Investment period closed. Reset with New Round.",
    fbVaultAdded: (amount, pts) => `+${amount} virtual investment added. +${pts} match point bonus earned.`,
    fbWheelLocked: "You must reach top 3 on the leaderboard to spin the bonus wheel.",
    fbWheelAlreadySpun: "The bonus wheel has already been spun this round.",
    fbWheelPoints: (label) => `Bonus wheel: ${label} added to your match points.`,
    fbWheelPower: "Bonus wheel: +10 Squad Power added.",
    fbWheelEmpty: "Bonus wheel: No bonus this round.",
    fbFormationChosen: (name) => `Formation ${name} selected.`,
    fbFormationRefund: (names) => `Bench full — refunded balance for ${names}.`,
    fbFormationBench: (names) => `${names} moved to bench in the new formation.`,
    fbPlayerSwap: (oldName, newName) => `${oldName} replaced with ${newName}. Balance updated.`,
    fbInsufficient: (amount) => `Insufficient balance. Need ${amount} for the swap.`,
    fbSlotGone: "This slot is no longer in the current formation.",
    fbSlotFull: "This slot is full. Pick another empty slot.",
    fbBenchSlotInvalid: "Select a valid bench slot.",
    fbBenchSlotFull: "This bench slot is full. Pick another empty slot.",
    fbSquadNoSlot: "No empty slot in the squad.",
    fbSquadFull: "Squad limit reached.",
    fbBalanceLow: "Insufficient balance.",
    fbSlotEmpty: "This slot is already empty.",
    fbSwapInvalid: "Select a valid slot for the swap."
  }
};

// Translation helper — falls back to TR, then to the raw key.
function t(key, ...args) {
  const dict = translations[state.language] || translations.tr;
  const value = dict[key] !== undefined ? dict[key] : translations.tr[key];
  if (value === undefined) return key;
  return typeof value === "function" ? value(...args) : value;
}

function setLanguage(language) {
  if (!["tr", "en"].includes(language)) return;
  if (state.language === language) return;
  state.language = language;
  renderAll();
}

function renderTranslations() {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll("[data-i18n-html]").forEach((el) => {
    el.innerHTML = t(el.dataset.i18nHtml);
  });
  document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
    el.setAttribute("aria-label", t(el.dataset.i18nAria));
  });
}

function renderLanguageSwitcher() {
  document.querySelectorAll("[data-language]").forEach((button) => {
    const isActive = button.dataset.language === state.language;
    button.classList.toggle("is-active", isActive);
    button.setAttribute("aria-pressed", String(isActive));
  });
  // Keep <html lang> in sync for screen readers and SEO
  document.documentElement.lang = state.language;
}

function bindLanguageSwitcher() {
  document.querySelectorAll("[data-language]").forEach((button) => {
    button.addEventListener("click", () => setLanguage(button.dataset.language));
  });
}

let feedbackTimeoutId = null;

function formatMoney(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0
  }).format(value);
}

function formatPoints(value) {
  return new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 0
  }).format(Math.max(0, Math.round(value)));
}

function formatCompactMoney(value) {
  const abs = Math.abs(value);
  if (abs >= 1000000) {
    const m = abs / 1000000;
    // Tam sayıysa "1M", değilse bir ondalık "4.8M"; "5.0M" → "5M"
    const formatted = Number.isInteger(m) ? String(m) : m.toFixed(1).replace(/\.0$/, "");
    return `$${formatted}M`;
  }
  if (abs >= 1000) return `$${Math.round(abs / 1000)}K`;
  return `$${abs}`;
}

function calculatePlayerPoints(player) {
  return Math.round(player.rating * 10);
}

function getPlayer(playerId) {
  return demoPlayers.find((player) => player.id === playerId);
}

function syncSquadStats() {
  state.squadCount = state.selectedPlayers.length;
  state.squadRatingPoints = state.selectedPlayers.reduce((total, playerId) => {
    const player = getPlayer(playerId);
    return player ? total + calculatePlayerPoints(player) : total;
  }, 0) + (state.squadRatingPointsBonus || 0);
}

function isSquadReady() {
  return state.selectedPlayers.length >= state.minimumPlayers;
}

function getSquadProgress() {
  const count = state.selectedPlayers.length;
  const percent = Math.min(100, Math.round((count / state.maxPlayers) * 100));
  const remaining = state.minimumPlayers - count;

  let message;
  if (count >= 16) {
    message = t("squadDone");
  } else if (count >= 11) {
    message = t("squadReadyXI");
  } else if (count >= state.minimumPlayers) {
    message = t("squadReadyDemo");
  } else if (count === 0) {
    message = t("squadStart", state.minimumPlayers);
  } else {
    message = t("squadNeedMore", remaining);
  }

  return { count, percent, message };
}

function renderSquadProgress() {
  const progressCount = document.querySelector("#squadProgressCount");
  const progressTrack = document.querySelector("#squadProgressTrack");
  const progressFill = document.querySelector("#squadProgressFill");
  const progressCopy = document.querySelector("#squadProgressCopy");
  const milestones = document.querySelectorAll(".squad-milestones [data-milestone]");

  if (!progressCount || !progressFill || !progressCopy) return;

  const { count, percent, message } = getSquadProgress();

  progressCount.textContent = `${count} / ${state.maxPlayers}`;
  progressFill.style.width = `${percent}%`;
  progressCopy.textContent = message;

  if (progressTrack) {
    progressTrack.setAttribute("aria-valuenow", String(count));
  }

  milestones.forEach((chip) => {
    const threshold = Number(chip.dataset.milestone);
    chip.classList.toggle("is-active", count >= threshold);
  });

  const lineupWarning = document.querySelector(".lineup-warning");
  if (lineupWarning) {
    const ready = count >= state.minimumPlayers;
    lineupWarning.classList.toggle("is-ready", ready);
    lineupWarning.textContent = ready
      ? t("lineupReady")
      : t("lineupWarning");
  }
}

function getCurrentLayout() {
  return formationLayouts[state.selectedFormation] || formationLayouts["4-4-2"];
}

function getSlot(slotId) {
  return getCurrentLayout().find((slot) => slot.id === slotId);
}

function getBenchSlot(slotId) {
  if (!Object.prototype.hasOwnProperty.call(state.benchSlots, slotId)) return null;
  return { id: slotId, label: "YEDEK" };
}

function isBenchSlot(slotId) {
  return Boolean(getBenchSlot(slotId));
}

function isBenchMode(mode = state.activePicker.mode) {
  return mode.endsWith("-bench");
}

function isManageMode(mode = state.activePicker.mode) {
  return mode.startsWith("manage");
}

function isReplaceMode(mode = state.activePicker.mode) {
  return mode.startsWith("replace");
}

function getSlotPlayerId(slotId) {
  if (isBenchSlot(slotId)) return state.benchSlots[slotId];
  return state.lineupSlots[slotId];
}

function getSelectedLineupPlayerIdsByPosition(position) {
  return Object.values(state.lineupSlots).filter((playerId) => {
    const player = getPlayer(playerId);
    return player && player.position === position;
  });
}

function getAssignedPlayerIds() {
  return [...Object.values(state.lineupSlots), ...Object.values(state.benchSlots)].filter(Boolean);
}

function getOpenSlot(position) {
  return getCurrentLayout().find((slot) => slot.position === position && !state.lineupSlots[slot.id]);
}

function getOpenBenchSlot() {
  const slotId = Object.keys(state.benchSlots).find((id) => !state.benchSlots[id]);
  return slotId ? getBenchSlot(slotId) : null;
}

function getFlagClass(player) {
  const flagClasses = {
    France: "flag-france",
    England: "flag-england",
    Brazil: "flag-brazil",
    Belgium: "flag-belgium",
    Netherlands: "flag-netherlands",
    Spain: "flag-spain",
    Croatia: "flag-croatia",
    Uruguay: "flag-uruguay",
    Morocco: "flag-morocco",
    Argentina: "flag-argentina",
    Portugal: "flag-portugal"
  };
  return flagClasses[player.country] || "flag-text";
}

function getFlagMarkup(player) {
  const tri = "<span></span><span></span><span></span>";
  switch (player.country) {
    case "France":
    case "Belgium":
    case "Netherlands":
    case "Spain":
    case "Croatia":
    case "Argentina":
      return tri;
    case "England":
      return "<span></span><span></span>";
    case "Brazil":
    case "Uruguay":
    case "Morocco":
    case "Portugal":
      return "";
    default:
      return `<span>${player.country.slice(0, 2).toUpperCase()}</span>`;
  }
}

// Returns a translated display label for a wheel reward object.
// Uses type/points/squadPower (language-neutral fields) so the label
// is always in the current language even after a language switch.
function getWheelRewardLabel(reward) {
  if (!reward) return "";
  if (reward.type === "squadPower") return `+${reward.squadPower} ${t("wheelLabelPower")}`;
  if (reward.type === "empty")      return t("wheelLabelNone");
  return `+${reward.points} ${t("wheelLabelPoints")}`;
}

function getBudgetImpact(player, replaceSlotId) {
  if (replaceSlotId) {
    const oldPlayer = getPlayer(getSlotPlayerId(replaceSlotId));
    if (oldPlayer) {
      const diff = player.price - oldPlayer.price;
      if (diff === 0) {
        return { label: t("noDiff"), status: "default", canAfford: true };
      }
      if (diff > 0) {
        const canAfford = state.balance >= diff;
        return {
          label: canAfford ? t("budgetExtra", formatCompactMoney(diff)) : t("budgetInsufficient"),
          status: canAfford ? "warning" : "danger",
          canAfford
        };
      }
      return {
        label: t("budgetRefund", formatCompactMoney(Math.abs(diff))),
        status: "default",
        canAfford: true
      };
    }
  }

  const afterBalance = state.balance - player.price;
  const canAfford = afterBalance >= 0;
  return {
    label: canAfford ? t("budgetRemaining", formatCompactMoney(afterBalance)) : t("budgetInsufficient"),
    status: canAfford ? "default" : "danger",
    canAfford
  };
}

function showFeedback(message) {
  const feedbackElements = document.querySelectorAll("[data-feedback]");
  if (!feedbackElements.length) return;

  const nextMessage = typeof message === "string" ? message.trim() : "";

  if (feedbackTimeoutId) {
    window.clearTimeout(feedbackTimeoutId);
    feedbackTimeoutId = null;
  }

  if (!nextMessage) {
    feedbackElements.forEach((feedbackElement) => {
      feedbackElement.textContent = "";
      feedbackElement.classList.remove("is-active");
    });
    return;
  }

  feedbackElements.forEach((feedbackElement) => {
    feedbackElement.textContent = nextMessage;
    feedbackElement.classList.add("is-active");
  });

  feedbackTimeoutId = window.setTimeout(() => {
    feedbackElements.forEach((feedbackElement) => {
      feedbackElement.textContent = "";
      feedbackElement.classList.remove("is-active");
    });
    feedbackTimeoutId = null;
  }, 2200);
}

function calculateAverageRating(players) {
  if (!players.length) return 0;
  const totalRating = players.reduce((sum, player) => sum + player.rating, 0);
  return totalRating / players.length;
}

function calculateMatchResult() {
  const players = state.selectedPlayers
    .map((playerId) => getPlayer(playerId))
    .filter(Boolean);

  const squadSize = players.length;
  const startingPlayers = Object.values(state.lineupSlots).filter(Boolean).length;
  const benchPlayers = Object.values(state.benchSlots).filter(Boolean).length;
  const avgRating = calculateAverageRating(players);
  const basePoints = players.reduce((sum, player) => sum + calculatePlayerPoints(player), 0);

  // Demo-only Rating Booster logic:
  // Each player gets a random performance delta (-0.4 to +0.6) applied to their base rating.
  // A separate random flag simulates "player's team lost" (45% probability, demo only).
  // Players whose simulated performance rating reaches 8.5+ AND whose demo team lost
  // earn a +15 booster bonus — matching the "8.5+ losing-team boost" rule shown in the UI.
  const boosterPlayers = players
    .map((player) => {
      const delta = -0.4 + Math.random() * 1.0;
      const performanceRating = Math.min(10, Math.max(6.5, player.rating + delta));
      const playerTeamLost = Math.random() < 0.45; // demo only: 45% chance of losing team
      return { player, performanceRating, playerTeamLost };
    })
    .filter(({ performanceRating, playerTeamLost }) => performanceRating >= 8.5 && playerTeamLost)
    .map(({ player, performanceRating }) => ({
      id: player.id,
      name: player.name,
      position: player.position,
      performanceRating: Math.round(performanceRating * 10) / 10,
      boostPoints: 15
    }));

  const boosterPoints = boosterPlayers.length * 15;
  const investmentBonusPoints = state.investmentBonusPoints || 0;
  // totalEarned is the single source of truth — vault included exactly once here.
  const totalEarned = basePoints + boosterPoints + investmentBonusPoints;
  const rankChange = Math.max(1, Math.round(totalEarned / 25));

  return {
    id: Date.now(),
    squadSize,
    startingPlayers,
    benchPlayers,
    basePoints,
    boosterPlayers,
    boosterPoints,
    investmentBonusPoints,   // snapshot for UI display — already inside totalEarned
    totalEarned,
    avgRating,
    rankChange,
    createdAt: new Date().toLocaleString("tr-TR", { hour12: false })
  };
}


function playDemoMatch() {
  if (state.matchSimulation.isProcessing) return;

  // Hard guard: once a match has been played this round, the only path forward
  // is "Yeni Tur Başlat" (which resets state). Prevents any hidden/duplicate
  // click, devtools trigger, or stale binding from re-running the match.
  if (state.matchSimulation.lastResult) {
    showFeedback(t("fbRoundDone"));
    return;
  }

  syncSquadStats();

  if (state.squadCount < state.minimumPlayers) {
    showFeedback(t("fbNotEnoughPlayers"));
    return;
  }

  state.matchSimulation.isProcessing = true;
  renderMatchPanel();

  window.setTimeout(() => {
    const result = calculateMatchResult();

    state.matchSimulation.isPlayed = true;
    state.matchSimulation.isProcessing = false;
    state.matchSimulation.lastResult = result;
    state.matchSimulation.history = [result, ...state.matchSimulation.history].slice(0, 3);
    // totalEarned already includes investmentBonusPoints — assign directly, no addition needed.
    state.totalPoints = result.totalEarned;
    state.transferOpen = false;
    state.matchResultModal.isOpen = true;
    checkBonusWheelUnlock();

    renderAll();
    showFeedback(t("fbMatchDone"));
  }, 700);
}

function renderStats() {
  syncSquadStats();

  const balanceValue = document.querySelector("#balanceValue");
  const squadCount = document.querySelector("#squadCount");
  const squadPowerPoints = document.querySelector("#squadPowerPoints");
  const transferStatus = document.querySelector("#transferStatus");
  const totalPoints = document.querySelector("#totalPoints");
  const lineupCount = document.querySelector(".lineup-count");

  if (balanceValue) balanceValue.textContent = formatMoney(state.balance);
  if (squadCount) squadCount.textContent = `${state.squadCount} / ${state.maxPlayers}`;
  if (squadPowerPoints) squadPowerPoints.textContent = formatPoints(state.squadRatingPoints);
  if (transferStatus) {
    transferStatus.textContent = state.transferOpen ? t("open") : t("closed");
    const transferCard = transferStatus.closest(".stat-card");
    if (transferCard) transferCard.classList.toggle("is-transfer-locked", !state.transferOpen);
  }
  if (totalPoints) totalPoints.textContent = formatPoints(state.totalPoints);
  if (lineupCount) lineupCount.textContent = `${state.squadCount} / ${state.maxPlayers}`;
}

function renderPitch() {
  const pitchSlots = document.querySelector("#pitchSlots");
  if (!pitchSlots) return;

  pitchSlots.innerHTML = "";

  getCurrentLayout().forEach((slotData) => {
    const player = getPlayer(state.lineupSlots[slotData.id]);
    const slot = document.createElement("button");

    slot.className = player ? "player-slot is-filled" : "player-slot";
    slot.type = "button";
    slot.dataset.slotId = slotData.id;
    slot.dataset.position = slotData.position;
    slot.style.left = `${slotData.left}%`;
    slot.style.top = `${slotData.top}%`;

    if (player) {
      slot.setAttribute("aria-label", `${player.name}, ${player.country}, ${slotData.position}`);
      slot.innerHTML = `
        <span class="slot-mini-flag player-flag ${getFlagClass(player)}" aria-hidden="true">${getFlagMarkup(player)}</span>
        <span class="slot-position">${slotData.position}</span>
        <strong>${player.name}</strong>
      `;
    } else {
      slot.removeAttribute("aria-label");
      slot.innerHTML = `
        <span class="slot-position">${slotData.position}</span>
        <strong>+</strong>
      `;
    }

    slot.addEventListener("click", () => {
      if (state.lineupSlots[slotData.id]) {
        openSlotManager(slotData.id);
        return;
      }
      openPositionPicker(slotData.id, slotData.position);
    });

    pitchSlots.appendChild(slot);
  });
}

function renderBench() {
  const benchSlots = document.querySelector("#benchSlots");
  const benchCount = document.querySelector("#benchCount");
  const benchKicker = document.querySelector(".bench-header .section-kicker");
  if (!benchSlots || !benchCount) return;
  if (benchKicker) benchKicker.textContent = t("bench");

  const filledBenchSlots = Object.values(state.benchSlots).filter(Boolean).length;
  benchCount.textContent = `${filledBenchSlots} / 5`;
  benchSlots.innerHTML = "";

  Object.keys(state.benchSlots).forEach((slotId) => {
    const player = getPlayer(state.benchSlots[slotId]);
    const slot = document.createElement("button");

    slot.className = player ? "bench-slot is-filled" : "bench-slot";
    slot.type = "button";
    slot.dataset.slotId = slotId;

    if (player) {
      slot.setAttribute("aria-label", t("benchSlotAriaFilled", player.name, player.country));
      slot.innerHTML = `
        <span class="bench-mini-flag player-flag ${getFlagClass(player)}" aria-hidden="true">${getFlagMarkup(player)}</span>
        <span class="bench-position">${t("benchSlotLabel")}</span>
        <strong>${player.name}</strong>
      `;
    } else {
      slot.setAttribute("aria-label", t("emptyBenchSlotAria"));
      slot.innerHTML = `
        <span class="bench-position">${t("benchSlotLabel")}</span>
        <strong>+</strong>
      `;
    }

    slot.addEventListener("click", () => {
      if (player) {
        openSlotManager(slotId);
        return;
      }
      openBenchPicker(slotId);
    });

    benchSlots.appendChild(slot);
  });
}

function renderMatchPanel() {
  const matchPanel = document.querySelector(".match-panel");
  const matchStatus = document.querySelector("#matchStatus");
  const playMatchButton = document.querySelector("#playMatchButton");
  const matchResult = document.querySelector("#matchResult");
  const matchReadyBanner = document.querySelector("#matchReadyBanner");
  const matchCopy = document.querySelector(".match-copy");
  const lastResult = state.matchSimulation.lastResult;
  const isReady = isSquadReady();

  if (!matchStatus || !playMatchButton || !matchResult) return;

  if (matchPanel) {
    matchPanel.classList.toggle("is-ready", isReady);
    matchPanel.classList.toggle("is-locked", !isReady);
    matchPanel.classList.toggle("is-played", Boolean(lastResult));
  }

  if (matchReadyBanner) {
    matchReadyBanner.classList.toggle("is-visible", isReady);
  }

  if (state.matchSimulation.isProcessing) {
    matchStatus.textContent = t("matchStatusSim");
    matchStatus.classList.remove("is-locked");
    playMatchButton.textContent = t("simulating");
    playMatchButton.disabled = true;
    playMatchButton.hidden = false;
    if (matchCopy) matchCopy.textContent = t("matchCopySim");
  } else if (lastResult) {
    matchStatus.textContent = t("matchStatusDone");
    matchStatus.classList.remove("is-locked");
    playMatchButton.textContent = t("playDemoMatch");
    playMatchButton.disabled = true;
    playMatchButton.hidden = true;
    playMatchButton.setAttribute("aria-hidden", "true");
    if (matchCopy) matchCopy.textContent = t("matchCopyDone");
  } else if (!isReady) {
    const remaining = state.minimumPlayers - state.selectedPlayers.length;
    matchStatus.textContent = t("matchStatusLocked");
    matchStatus.classList.add("is-locked");
    playMatchButton.textContent = t("players6Required");
    playMatchButton.disabled = true;
    playMatchButton.hidden = false;
    playMatchButton.removeAttribute("aria-hidden");
    if (matchCopy) {
      matchCopy.textContent = remaining === state.minimumPlayers
        ? t("matchCopyLockedStart", state.minimumPlayers)
        : t("matchCopyLocked", remaining);
    }
  } else {
    matchStatus.textContent = t("matchStatusReady");
    matchStatus.classList.remove("is-locked");
    playMatchButton.textContent = t("playDemoMatch");
    playMatchButton.disabled = false;
    playMatchButton.hidden = false;
    playMatchButton.removeAttribute("aria-hidden");
    if (matchCopy) matchCopy.textContent = t("matchCopyReady");
  }

  if (!lastResult) {
    matchResult.hidden = true;
    matchResult.innerHTML = "";
    return;
  }

  // Compact summary — full breakdown lives in the premium popup.
  matchResult.hidden = false;
  matchResult.innerHTML = `
    <div class="match-summary-card">
      <div class="match-summary-total">
        <span>${t("matchCompletedShort")}</span>
        <strong>${formatPoints(state.totalPoints)}</strong>
        <small>${t("totalPointsShort")}</small>
      </div>
      <div class="match-summary-meta">
        <article class="match-summary-meta-card">
          <span>${t("rankChangeLabel")}</span>
          <strong class="is-cyan">+${lastResult.rankChange}</strong>
        </article>
        <article class="match-summary-meta-card">
          <span>${t("avgRatingLabel")}</span>
          <strong>${lastResult.avgRating.toFixed(1)}</strong>
        </article>
      </div>
      <div class="match-summary-actions">
        <button class="ghost-button" type="button" id="reopenResultButton">
          ${t("viewResultAgain")}
        </button>
        <button class="ghost-button is-danger" type="button" id="nextChallengeButton">
          ${t("startNewRound")}
        </button>
      </div>
    </div>
  `;

  const reopenBtn = matchResult.querySelector("#reopenResultButton");
  if (reopenBtn) {
    reopenBtn.addEventListener("click", () => {
      state.matchResultModal.isOpen = true;
      renderMatchResultModal();
    });
  }

  const nextChallengeButton = matchResult.querySelector("#nextChallengeButton");
  if (nextChallengeButton) {
    nextChallengeButton.addEventListener("click", openResetConfirm);
  }
}

// Static opponent teams — fixed demo points, never random, never changes between renders.
const OPPONENT_TEAMS = [
  { name: "Royal Strikers", points: 1250, movement:  3 },
  { name: "Samba Kings",    points: 1120, movement:  1 },
  { name: "Golden Boot FC", points:  980, movement: -1 },
  { name: "Oranje Elite",   points:  890, movement:  2 },
  { name: "Atlas FC",       points:  810, movement:  0 },
  { name: "Neon Lions",     points:  740, movement: -2 },
  { name: "Bosphorus XI",   points:  690, movement:  1 },
  { name: "Titan United",   points:  620, movement: -1 },
  { name: "Atlas Lions",    points:  560, movement:  0 }
];

function getLeaderboardRows() {
  const lastResult = state.matchSimulation.lastResult;
  const hasPlayed = Boolean(lastResult);

  // Before match: show opponents in fixed order + XI Royale waiting at the bottom.
  if (!hasPlayed) {
    const rows = OPPONENT_TEAMS.map((team, index) => ({
      rank: index + 1,
      name: team.name,
      points: team.points,
      movement: team.movement,
      isCurrent: false,
      isWaiting: false
    }));
    rows.push({
      rank: rows.length + 1,
      name: "XI Royale",
      points: 0,
      movement: null,
      isCurrent: true,
      isWaiting: true
    });
    return rows;
  }

  // After match: merge XI Royale into opponents, sort by points desc, assign real ranks.
  const xiRoyaleRow = {
    name: "XI Royale",
    points: state.totalPoints,
    movement: lastResult.rankChange,
    isCurrent: true,
    isWaiting: false
  };

  const opponentRows = OPPONENT_TEAMS.map((team) => ({
    name: team.name,
    points: team.points,
    movement: team.movement,
    isCurrent: false,
    isWaiting: false
  }));

  return [...opponentRows, xiRoyaleRow]
    .sort((a, b) => b.points - a.points)
    .map((row, index) => ({ ...row, rank: index + 1 }));
}

function renderBoardHero() {
  const boardRankBadge = document.querySelector("#boardRankBadge");
  const boardTotalPoints = document.querySelector("#boardTotalPoints");
  const boardRankChange = document.querySelector("#boardRankChange");
  const boardAvgRating = document.querySelector("#boardAvgRating");
  const boardHeroCopy = document.querySelector("#boardHeroCopy");
  const lastResult = state.matchSimulation.lastResult;

  if (!boardRankBadge || !boardTotalPoints || !boardRankChange || !boardAvgRating || !boardHeroCopy) return;

  if (!lastResult) {
    boardRankBadge.textContent = "#---";
    boardTotalPoints.textContent = "0";
    boardRankChange.textContent = "—";
    boardAvgRating.textContent = "—";
    boardHeroCopy.textContent = t("boardHeroCopyEmpty");
    return;
  }

  const rows = getLeaderboardRows();
  const currentRow = rows.find((r) => r.isCurrent);
  const currentRank = currentRow ? currentRow.rank : "?";

  // Real rank movement: XI Royale starts at the bottom (rank 10 while waiting),
  // so actual positions gained = startingRank − newRank.
  const startingRank = OPPONENT_TEAMS.length + 1; // 10
  const actualRankChange = typeof currentRank === "number"
    ? startingRank - currentRank
    : 0;
  const rankChangeDisplay = actualRankChange > 0
    ? `+${actualRankChange}`
    : String(actualRankChange);

  let heroCopy;
  if (currentRank <= 3) {
    heroCopy = t("boardHeroCopyPodium");
  } else if (currentRank <= 6) {
    heroCopy = t("boardHeroCopyClose");
  } else {
    heroCopy = t("boardHeroCopyFar");
  }

  heroCopy += " " + t("boardHeroCopyVaultNote");

  boardRankBadge.textContent = `#${currentRank}`;
  boardTotalPoints.textContent = formatPoints(state.totalPoints);
  boardRankChange.textContent = rankChangeDisplay;
  boardAvgRating.textContent = lastResult.avgRating.toFixed(1);
  boardHeroCopy.textContent = heroCopy;
}

function renderPodium() {
  const podiumGrid = document.querySelector("#podiumGrid");
  if (!podiumGrid) return;

  const topThree = getLeaderboardRows().slice(0, 3);

  podiumGrid.innerHTML = topThree.map((row) => {
    const classes = ["podium-card"];
    if (row.rank === 1) classes.push("is-first");
    if (row.isCurrent) classes.push("is-current");
    if (row.isWaiting) classes.push("is-locked");

    const pointsText = row.isWaiting ? t("waitingForMatch") : `${formatPoints(row.points)} ${t("pts")}`;

    return `
      <article class="${classes.join(" ")}">
        <span class="podium-rank">#${row.rank}</span>
        <p class="podium-team">${row.name}${row.isCurrent ? ` • ${t("you")}` : ""}</p>
        <strong class="podium-points">${pointsText}</strong>
      </article>
    `;
  }).join("");
}

function renderLeaderboardList() {
  const leaderboardList = document.querySelector("#leaderboardList");
  if (!leaderboardList) return;

  const rows = getLeaderboardRows();

  leaderboardList.innerHTML = rows.map((row) => {
    let movementClass = "is-neutral";
    let movementLabel = "0";

    if (row.isWaiting) {
      movementLabel = t("waiting");
    } else if (row.movement > 0) {
      movementClass = "is-up";
      movementLabel = `+${row.movement}`;
    } else if (row.movement < 0) {
      movementClass = "is-down";
      movementLabel = String(row.movement);
    }

    const pointsText = row.isWaiting ? t("waitingForMatch") : `${formatPoints(row.points)} ${t("pts")}`;

    return `
      <article class="leaderboard-row ${row.isCurrent ? "is-current" : ""}" ${row.isCurrent ? 'aria-current="true"' : ""}>
        <div class="leaderboard-row-left">
          <span class="leaderboard-rank">#${row.rank}</span>
          <div class="leaderboard-team">
            <span>${row.name}</span>
            ${row.isCurrent ? `<span class="leaderboard-you">${t("you")}</span>` : ""}
          </div>
        </div>
        <div class="leaderboard-row-right">
          <strong class="leaderboard-points">${pointsText}</strong>
          <span class="movement-badge ${movementClass}">${movementLabel}</span>
        </div>
      </article>
    `;
  }).join("");
}

function renderMatchHistory() {
  const historyList = document.querySelector("#historyList");
  if (!historyList) return;

  const history = state.matchSimulation.history.slice(0, 3);

  if (!history.length) {
    historyList.innerHTML = `
      <p class="board-empty-state">${t("historyEmpty")}</p>
    `;
    return;
  }

  historyList.innerHTML = history.map((match, index) => {
    const title = index === 0 ? t("lastMatch") : t("previousMatch", index + 1);
    return `
      <article class="history-item">
        <div class="history-item-head">
          <span class="history-item-title">${title}</span>
          <span class="history-item-time">${match.createdAt}</span>
        </div>
        <p class="history-item-points">+${formatPoints(match.totalEarned)} ${t("pts")}</p>
        <div class="history-item-meta">
          <div class="history-meta-pill">
            <span>${t("avg")}</span>
            <strong>${match.avgRating.toFixed(1)}</strong>
          </div>
          <div class="history-meta-pill">
            <span>${t("kadro")}</span>
            <strong>${match.squadSize}/16</strong>
          </div>
          <div class="history-meta-pill">
            <span>${t("rank")}</span>
            <strong>+${match.rankChange}</strong>
          </div>
          <div class="history-meta-pill">
            <span>${t("boost")}</span>
            <strong>${match.boosterPoints ? `+${match.boosterPoints}` : "—"}</strong>
          </div>
          ${(match.investmentBonusPoints || 0) > 0
            ? `<div class="history-meta-pill is-vault">
                <span>${t("kasa")}</span>
                <strong>+${formatPoints(match.investmentBonusPoints)}</strong>
              </div>`
            : ""}
        </div>
      </article>
    `;
  }).join("");
}

function renderBoardBreakdown() {
  const container = document.querySelector("#boardBreakdown");
  if (!container) return;

  const result = state.matchSimulation.lastResult;

  if (!result) {
    container.innerHTML = `
      <p class="board-empty-state">${t("breakdownEmpty")}</p>
    `;
    return;
  }

  const basePoints    = result.basePoints || 0;
  const boosterPoints = result.boosterPoints || 0;
  const vaultPoints   = result.investmentBonusPoints || 0;

  // Wheel bonus — only show card if wheel has been spun this round.
  const wheelReward  = state.bonusWheel.lastReward;
  const hasWheelSpun = Boolean(state.bonusWheel.hasSpun && wheelReward);

  const cards = [
    { label: t("breakdownMatchPoints"), value: basePoints,    suffix: "", modifier: ""        },
    { label: t("boosterPointsLabel"),   value: boosterPoints, suffix: "", modifier: boosterPoints === 0 ? "is-muted" : "" },
    { label: t("cashVaultBonus"),       value: vaultPoints,   suffix: "", modifier: "is-vault" + (vaultPoints === 0 ? " is-muted" : "") }
  ];

  if (hasWheelSpun) {
    if (wheelReward.type === "points") {
      const wp = wheelReward.points || 0;
      cards.push({
        label: t("wheelBonus"),
        value: wp,
        suffix: ` ${t("points")}`,
        modifier: "is-wheel" + (wp === 0 ? " is-muted" : "")
      });
    } else if (wheelReward.type === "squadPower") {
      cards.push({
        label: t("wheelBonus"),
        value: wheelReward.squadPower,
        suffix: ` ${t("squadPower")}`,
        modifier: "is-wheel"
      });
    } else {
      // empty reward
      cards.push({
        label: t("wheelBonus"),
        value: 0,
        suffix: "",
        modifier: "is-wheel is-muted"
      });
    }
  }

  // Final total row — single source of truth, matches popup + leaderboard.
  // Always last so it visually anchors the breakdown.
  cards.push({
    label:    t("totalPointsBoardLabel"),
    sublabel: t("breakdownTotalSub"),
    value:    state.totalPoints,
    suffix:   "",
    modifier: "is-total",
    isTotal:  true
  });

  container.innerHTML = cards.map((card) => {
    if (card.isTotal) {
      return `
        <article class="board-breakdown-card ${card.modifier}">
          <div class="board-breakdown-total-text">
            <span>${card.label}</span>
            <small>${card.sublabel}</small>
          </div>
          <strong>+${formatPoints(card.value)}</strong>
        </article>
      `;
    }
    const subtitleHTML = card.subtitle
      ? `<small class="board-breakdown-sub">${card.subtitle}</small>`
      : "";
    return `
      <article class="board-breakdown-card ${card.modifier}">
        <span>${card.label}</span>
        <strong>+${formatPoints(card.value)}${card.suffix}</strong>
        ${subtitleHTML}
      </article>
    `;
  }).join("");
}

function renderBoard() {
  renderBoardHero();
  renderBoardBreakdown();
  renderPodium();
  renderLeaderboardList();
  renderMatchHistory();
}

function moveLineupOverflowToBenchOrRefund(playerIds) {
  const moved = [];
  const refunded = [];

  playerIds.forEach((playerId) => {
    const player = getPlayer(playerId);
    if (!player) return;

    const openBenchSlot = getOpenBenchSlot();
    if (openBenchSlot) {
      state.benchSlots[openBenchSlot.id] = player.id;
      moved.push(player);
      return;
    }

    state.selectedPlayers = state.selectedPlayers.filter((selectedId) => selectedId !== player.id);
    state.balance += player.price;
    refunded.push(player);
  });

  return { moved, refunded };
}

function rebuildLineupSlots() {
  const nextLineupSlots = {};
  const overflowPlayerIds = [];
  const positions = ["FWD", "MID", "DEF", "GK"];

  positions.forEach((position) => {
    const positionSlots = getCurrentLayout().filter((slot) => slot.position === position);
    const selectedPlayerIds = getSelectedLineupPlayerIdsByPosition(position);

    positionSlots.forEach((slot, index) => {
      const playerId = selectedPlayerIds[index];
      if (playerId) nextLineupSlots[slot.id] = playerId;
    });

    if (selectedPlayerIds.length > positionSlots.length) {
      overflowPlayerIds.push(...selectedPlayerIds.slice(positionSlots.length));
    }
  });

  state.lineupSlots = nextLineupSlots;
  const result = moveLineupOverflowToBenchOrRefund(overflowPlayerIds);
  closePositionPicker({ render: false });
  return result;
}

function assignPlayerToLineupSlot(player, slotId) {
  const slot = getSlot(slotId);
  if (!slot) {
    showFeedback(t("fbSlotGone"));
    return false;
  }

  if (slot.position !== player.position) {
    showFeedback(t("slotPositionError", slot.position));
    return false;
  }

  if (state.lineupSlots[slot.id]) {
    showFeedback(t("fbSlotFull"));
    return false;
  }

  state.lineupSlots = {
    ...state.lineupSlots,
    [slot.id]: player.id
  };
  return true;
}

function assignPlayerToBenchSlot(player, slotId) {
  const slot = getBenchSlot(slotId);
  if (!slot) {
    showFeedback(t("fbBenchSlotInvalid"));
    return false;
  }

  if (state.benchSlots[slot.id]) {
    showFeedback(t("fbBenchSlotFull"));
    return false;
  }

  state.benchSlots = {
    ...state.benchSlots,
    [slot.id]: player.id
  };
  return true;
}

function assignPlayerToAnyOpenSlot(player) {
  const lineupSlot = getOpenSlot(player.position);
  if (lineupSlot) return assignPlayerToLineupSlot(player, lineupSlot.id);

  const benchSlot = getOpenBenchSlot();
  if (benchSlot) return assignPlayerToBenchSlot(player, benchSlot.id);

  showFeedback(t("fbSquadNoSlot"));
  return false;
}

function buyPlayer(playerId, options = {}) {
  const player = getPlayer(playerId);
  if (!player) return;

  if (!state.transferOpen) {
    showFeedback(t("fbTransferClosed"));
    return;
  }

  if (state.selectedPlayers.includes(player.id)) {
    showFeedback(t("fbPlayerAlreadyInSquad", player.name));
    return;
  }

  if (state.selectedPlayers.length >= state.maxPlayers) {
    showFeedback(t("fbSquadFull"));
    return;
  }

  if (state.balance < player.price) {
    showFeedback(t("fbBalanceLow"));
    return;
  }

  const placed = options.slotId
    ? isBenchSlot(options.slotId)
      ? assignPlayerToBenchSlot(player, options.slotId)
      : assignPlayerToLineupSlot(player, options.slotId)
    : assignPlayerToAnyOpenSlot(player);

  if (!placed) return;

  state.balance -= player.price;
  state.selectedPlayers = state.selectedPlayers.concat(player.id);

  closePositionPicker({ render: false });
  renderAll();

  if (isSquadReady() && !state.matchSimulation.readyFeedbackShown) {
    state.matchSimulation.readyFeedbackShown = true;
    showFeedback(t("squadReadyTitle") + ". " + t("squadReadyDesc"));
  } else {
    showFeedback(t("fbPlayerAdded", player.name));
  }
}

function removePlayerFromAnySlot(slotId) {
  if (!state.transferOpen) {
    showFeedback(t("fbTransferClosed"));
    closePositionPicker();
    return;
  }

  const playerId = getSlotPlayerId(slotId);
  const player = getPlayer(playerId);

  if (!player) {
    showFeedback(t("fbSlotEmpty"));
    closePositionPicker();
    return;
  }

  if (isBenchSlot(slotId)) {
    state.benchSlots = {
      ...state.benchSlots,
      [slotId]: null
    };
  } else {
    const nextLineupSlots = { ...state.lineupSlots };
    delete nextLineupSlots[slotId];
    state.lineupSlots = nextLineupSlots;
  }

  state.selectedPlayers = state.selectedPlayers.filter((selectedId) => selectedId !== player.id);
  state.balance += player.price;

  closePositionPicker({ render: false });
  renderAll();
  showFeedback(t("fbPlayerRemoved", player.name));
}

function replacePlayerInAnySlot(newPlayerId, slotId) {
  if (!state.transferOpen) {
    showFeedback(t("fbTransferClosed"));
    return;
  }

  const oldPlayerId = getSlotPlayerId(slotId);
  const oldPlayer = getPlayer(oldPlayerId);
  const newPlayer = getPlayer(newPlayerId);
  const lineupSlot = getSlot(slotId);
  const benchSlot = getBenchSlot(slotId);

  if (!oldPlayer || !newPlayer || (!lineupSlot && !benchSlot)) {
    showFeedback(t("fbSwapInvalid"));
    return;
  }

  if (lineupSlot && newPlayer.position !== lineupSlot.position) {
    showFeedback(t("slotPositionError", lineupSlot.position));
    return;
  }

  if (newPlayer.id === oldPlayer.id) {
    showFeedback(t("fbPlayerAlreadyInSlot", newPlayer.name));
    return;
  }

  if (state.selectedPlayers.includes(newPlayer.id)) {
    showFeedback(t("fbPlayerAlreadyInSquadElsewhere", newPlayer.name));
    return;
  }

  const priceDifference = newPlayer.price - oldPlayer.price;
  if (priceDifference > state.balance) {
    showFeedback(t("fbInsufficient", formatMoney(priceDifference)));
    return;
  }

  if (benchSlot) {
    state.benchSlots = {
      ...state.benchSlots,
      [slotId]: newPlayer.id
    };
  } else {
    state.lineupSlots = {
      ...state.lineupSlots,
      [slotId]: newPlayer.id
    };
  }

  state.selectedPlayers = state.selectedPlayers
    .filter((playerId) => playerId !== oldPlayer.id)
    .concat(newPlayer.id);
  state.balance -= priceDifference;

  closePositionPicker({ render: false });
  renderAll();
  showFeedback(t("fbPlayerSwap", oldPlayer.name, newPlayer.name));
}

// ── Scout card: informational only, no buy flow. ────────────
// Player acquisition happens exclusively through the pitch/bench picker
// or the Auto Squad Builder. This card is a preview, not a marketplace.
function createScoutPlayerCard(player) {
  const card = document.createElement("article");
  const isSelected = state.selectedPlayers.includes(player.id);
  const price      = Math.round(player.price / 1000);
  const flagClass  = getFlagClass(player);

  card.className = "scout-player-card";
  if (isSelected) card.classList.add("is-owned");

  card.innerHTML = `
    <div class="player-flag ${flagClass}" aria-hidden="true">${getFlagMarkup(player)}</div>
    <div class="scout-player-info">
      <strong>${player.name}</strong>
      <span>${player.country} • ${player.position} • Rating ${player.rating}</span>
    </div>
    <div class="scout-player-meta">
      <span class="scout-price">$${price}K</span>
      ${isSelected
        ? `<span class="scout-badge is-owned">${t("inSquad")}</span>`
        : `<span class="scout-badge">${t("scoutBadge")}</span>`}
    </div>
  `;

  return card;
}

function renderScoutList() {
  const scoutLists = document.querySelectorAll("[data-scout-list]");
  if (!scoutLists.length) return;

  // Top 3 by rating for the lineup scout preview.
  const topThree = [...demoPlayers]
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 3);

  scoutLists.forEach((listElement) => {
    listElement.innerHTML = "";
    topThree.forEach((player) => {
      listElement.appendChild(createScoutPlayerCard(player));
    });
  });
}

function createPickerPlayerCard(player) {
  const currentPlayerId = getSlotPlayerId(state.activePicker.slotId);
  const assignedPlayerIds = getAssignedPlayerIds();
  const isCurrent = isReplaceMode() && player.id === currentPlayerId;
  const isSelectedElsewhere = assignedPlayerIds.includes(player.id) && player.id !== currentPlayerId;
  const card = document.createElement("article");
  const price = Math.round(player.price / 1000);
  const flagClass = getFlagClass(player);

  const isLocked = !state.transferOpen;
  const showImpact = !isCurrent && !isSelectedElsewhere && !isLocked;
  const replaceSlotId = isReplaceMode() ? state.activePicker.slotId : null;
  const impact = showImpact ? getBudgetImpact(player, replaceSlotId) : null;

  let buttonLabel, buttonDisabled;
  if (isCurrent) {
    buttonLabel = t("pickerCurrent");
    buttonDisabled = true;
  } else if (isSelectedElsewhere) {
    buttonLabel = t("pickerTaken");
    buttonDisabled = true;
  } else if (isLocked) {
    buttonLabel = t("pickerClosed");
    buttonDisabled = true;
  } else if (impact && !impact.canAfford) {
    buttonLabel = t("pickerInsufficient");
    buttonDisabled = true;
  } else {
    buttonLabel = t("pickerBuy");
    buttonDisabled = false;
  }

  const impactHTML = isLocked && !isCurrent && !isSelectedElsewhere
    ? `<span class="budget-impact">${t("pickerTransferClosed")}</span>`
    : impact
      ? `<span class="budget-impact${impact.status !== "default" ? ` is-${impact.status}` : ""}">${impact.label}</span>`
      : "";

  card.className = "player-card";
  if (isCurrent || isSelectedElsewhere) card.classList.add("is-owned");
  if (isCurrent) card.classList.add("is-current");

  card.innerHTML = `
    <div class="player-flag ${flagClass}" aria-hidden="true">${getFlagMarkup(player)}</div>
    <div class="player-info">
      <strong>${player.name}</strong>
      <span>${player.country} • ${player.position} • Rating ${player.rating}</span>
    </div>
    <div class="player-price">
      <strong>$${price}K</strong>
      ${impactHTML}
      <button type="button">${buttonLabel}</button>
    </div>
  `;

  const button = card.querySelector("button");
  if (!button) return card;

  button.disabled = buttonDisabled;
  button.addEventListener("click", () => {
    if (isReplaceMode()) {
      replacePlayerInAnySlot(player.id, state.activePicker.slotId);
      return;
    }
    buyPlayer(player.id, { slotId: state.activePicker.slotId });
  });

  return card;
}

function renderPlayerPicker() {
  const pickerTitle = document.querySelector("#pickerTitle");
  const pickerModeLabel = document.querySelector("#pickerModeLabel");
  const pickerPosition = document.querySelector("#pickerPosition");
  const pickerBalance = document.querySelector("#pickerBalance");
  const pickerNote = document.querySelector("#pickerNote");
  const pickerList = document.querySelector("#pickerList");

  if (!pickerTitle || !pickerModeLabel || !pickerPosition || !pickerBalance || !pickerNote || !pickerList) return;

  const benchMode = isBenchMode();
  const replaceMode = isReplaceMode();
  const position = state.activePicker.position;
  const players = benchMode ? demoPlayers : demoPlayers.filter((player) => player.position === position);

  pickerModeLabel.textContent = benchMode ? t("benchPickerKicker") : t("positionPick");
  pickerTitle.textContent = benchMode ? t("benchPickerTitle") : t("pickerPositionTitle", position);
  pickerPosition.textContent = benchMode ? t("pickerBenchSlotLabel") : t("pickerPositionLabel", position);
  pickerBalance.textContent = t("pickerBalanceLabel", formatMoney(state.balance));
  pickerNote.textContent = replaceMode ? t("pickerCurrentNote") : t("cannotReselect");

  pickerList.classList.remove("is-management");
  pickerList.innerHTML = "";
  players.forEach((player) => {
    pickerList.appendChild(createPickerPlayerCard(player));
  });
}

function renderSlotManager() {
  const pickerTitle = document.querySelector("#pickerTitle");
  const pickerModeLabel = document.querySelector("#pickerModeLabel");
  const pickerPosition = document.querySelector("#pickerPosition");
  const pickerBalance = document.querySelector("#pickerBalance");
  const pickerNote = document.querySelector("#pickerNote");
  const pickerList = document.querySelector("#pickerList");
  const lineupSlot = getSlot(state.activePicker.slotId);
  const benchSlot = getBenchSlot(state.activePicker.slotId);
  const player = getPlayer(getSlotPlayerId(state.activePicker.slotId));

  if (!pickerTitle || !pickerModeLabel || !pickerPosition || !pickerBalance || !pickerNote || !pickerList) return;

  if (!player || (!lineupSlot && !benchSlot)) {
    closePositionPicker();
    return;
  }

  const slotLabel = benchSlot ? t("benchSlotLabel") : lineupSlot.position;

  pickerModeLabel.textContent = t("slotManagementKicker");
  pickerTitle.textContent = player.name;
  pickerPosition.textContent = t("pickerPositionLabel", slotLabel);
  pickerBalance.textContent = t("pickerBalanceLabel", formatMoney(state.balance));
  pickerNote.textContent = t("pickerPointsLabel", calculatePlayerPoints(player));

  pickerList.classList.add("is-management");
  pickerList.innerHTML = `
    <article class="slot-manager-card">
      <p class="slot-manager-name">${player.name}</p>
      <div class="slot-manager-grid">
        <div class="slot-manager-stat">
          <span>${t("position")}</span>
          <strong>${player.position}</strong>
        </div>
        <div class="slot-manager-stat">
          <span>${t("statCountry")}</span>
          <strong>${player.country}</strong>
        </div>
        <div class="slot-manager-stat">
          <span>Rating</span>
          <strong>${player.rating}</strong>
        </div>
        <div class="slot-manager-stat">
          <span>${t("statPrice")}</span>
          <strong>${formatMoney(player.price)}</strong>
        </div>
        <div class="slot-manager-stat">
          <span>${t("statSquadPts")}</span>
          <strong>${calculatePlayerPoints(player)}</strong>
        </div>
        <div class="slot-manager-stat">
          <span>${t("statCurrentBalance")}</span>
          <strong>${formatMoney(state.balance)}</strong>
        </div>
      </div>
    </article>

    <div class="slot-manager-actions">
      <button class="slot-action-button is-primary" type="button" data-slot-action="replace" ${!state.transferOpen ? "disabled" : ""}>
        ${t("slotActionReplace")}
      </button>
      <button class="slot-action-button is-danger" type="button" data-slot-action="remove" ${!state.transferOpen ? "disabled" : ""}>
        ${t("slotActionRemove")}
      </button>
      <button class="slot-action-button is-neutral" type="button" data-slot-action="close">
        ${t("close")}
      </button>
    </div>
    ${!state.transferOpen ? `<p class="transfer-lock-note">${t("transferCopyClosed")}</p>` : ""}
  `;

  const replaceButton = pickerList.querySelector('[data-slot-action="replace"]');
  const removeButton = pickerList.querySelector('[data-slot-action="remove"]');
  const closeButton = pickerList.querySelector('[data-slot-action="close"]');

  if (replaceButton) {
    replaceButton.addEventListener("click", () => {
      if (benchSlot) {
        openBenchPicker(benchSlot.id, "replace-bench");
        return;
      }
      openPositionPicker(lineupSlot.id, lineupSlot.position, "replace-lineup");
    });
  }

  if (removeButton) {
    removeButton.addEventListener("click", () => {
      removePlayerFromAnySlot(state.activePicker.slotId);
    });
  }

  if (closeButton) {
    closeButton.addEventListener("click", () => {
      closePositionPicker();
    });
  }
}

function renderPickerModal() {
  const modal = document.querySelector("#pickerModal");
  const pickerList = document.querySelector("#pickerList");
  const isOpen = state.activePicker.isOpen && state.activePicker.slotId;

  if (!modal || !pickerList) return;

  modal.classList.toggle("is-open", Boolean(isOpen));
  modal.setAttribute("aria-hidden", String(!isOpen));
  updateBodyModalState();

  if (!isOpen) {
    pickerList.classList.remove("is-management");
    pickerList.innerHTML = "";
    return;
  }

  if (isManageMode()) {
    renderSlotManager();
    return;
  }

  renderPlayerPicker();
}

function focusPickerCloseButton() {
  window.requestAnimationFrame(() => {
    const closeButton = document.querySelector("#closePickerButton");
    if (closeButton && state.activePicker.isOpen) {
      closeButton.focus();
    }
  });
}

function openPositionPicker(slotId, position, mode = "pick-lineup") {
  state.selectedSlot = { id: slotId, position };
  state.activePicker = {
    isOpen: true,
    mode,
    slotId,
    position
  };

  renderPickerModal();
  focusPickerCloseButton();
}

function openBenchPicker(slotId, mode = "pick-bench") {
  if (!getBenchSlot(slotId)) return;

  state.selectedSlot = { id: slotId, position: null };
  state.activePicker = {
    isOpen: true,
    mode,
    slotId,
    position: null
  };

  renderPickerModal();
  focusPickerCloseButton();
}

function openSlotManager(slotId) {
  const lineupSlot = getSlot(slotId);
  const benchSlot = getBenchSlot(slotId);
  const player = getPlayer(getSlotPlayerId(slotId));

  if (!lineupSlot && !benchSlot) return;

  if (!player) {
    if (benchSlot) {
      openBenchPicker(benchSlot.id);
      return;
    }
    openPositionPicker(lineupSlot.id, lineupSlot.position);
    return;
  }

  state.selectedSlot = {
    id: slotId,
    position: lineupSlot ? lineupSlot.position : null
  };
  state.activePicker = {
    isOpen: true,
    mode: benchSlot ? "manage-bench" : "manage-lineup",
    slotId,
    position: lineupSlot ? lineupSlot.position : null
  };

  renderPickerModal();
  focusPickerCloseButton();
}

function closePositionPicker(options = {}) {
  const shouldRender = options.render !== false;

  state.selectedSlot = null;
  state.activePicker = {
    isOpen: false,
    mode: "pick-lineup",
    slotId: null,
    position: null
  };

  if (shouldRender) {
    renderPickerModal();
  }
}

function openResetConfirm() {
  state.resetConfirmOpen = true;
  renderResetConfirm();
}

function closeResetConfirm() {
  state.resetConfirmOpen = false;
  renderResetConfirm();
}

function resetSquad() {
  state.balance = 1000000;
  state.selectedPlayers = [];
  state.lineupSlots = {};
  state.benchSlots = {
    "bench-1": null,
    "bench-2": null,
    "bench-3": null,
    "bench-4": null,
    "bench-5": null
  };
  state.squadCount = 0;
  state.totalPoints = 0;
  state.squadRatingPoints = 0;
  state.transferOpen = true;
  state.matchSimulation.isPlayed = false;
  state.matchSimulation.isProcessing = false;
  state.matchSimulation.lastResult = null;
  state.matchSimulation.history = [];
  state.matchSimulation.readyFeedbackShown = false;
  state.squadRatingPointsBonus = 0;
  state.bonusWheel.isUnlocked = false;
  state.bonusWheel.isOpen = false;
  state.bonusWheel.isSpinning = false;
  state.bonusWheel.hasSpun = false;
  state.bonusWheel.lastReward = null;
  state.bonusWheel.selectedRewardIndex = null;
  state.bonusWheel.rotation = 0;
  state.bonusWheel.pendingOpen = false;
  state.investmentBonusPoints = 0;
  state.demoInvestmentAmount = 0;
  state.matchResultModal.isOpen = false;

  closeResetConfirm();
  closePositionPicker({ render: false });
  renderAll();
  showFeedback(t("fbSquadReset"));
}

function renderResetConfirm() {
  const modal = document.querySelector("#resetModal");
  if (!modal) return;

  modal.classList.toggle("is-open", state.resetConfirmOpen);
  modal.setAttribute("aria-hidden", String(!state.resetConfirmOpen));
  updateBodyModalState();
}

function openRulesModal() {
  state.rulesModalOpen = true;
  renderRulesModal();
}

function closeRulesModal() {
  state.rulesModalOpen = false;
  renderRulesModal();
}

function renderRulesModal() {
  const modal = document.querySelector("#rulesModal");
  if (!modal) return;

  modal.classList.toggle("is-open", state.rulesModalOpen);
  modal.setAttribute("aria-hidden", String(!state.rulesModalOpen));
  updateBodyModalState();

  if (state.rulesModalOpen) {
    window.requestAnimationFrame(() => {
      const closeBtn = modal.querySelector("[data-close-rules]");
      if (closeBtn) closeBtn.focus();
    });
  }
}

function bindRulesModalControls() {
  const openButton = document.querySelector("#openRulesButton");
  if (openButton) openButton.addEventListener("click", openRulesModal);

  document.querySelectorAll("[data-close-rules]").forEach((el) => {
    el.addEventListener("click", closeRulesModal);
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && state.rulesModalOpen) {
      closeRulesModal();
    }
  });
}

function bindResetControls() {
  const resetSquadButton = document.querySelector("#resetSquadButton");
  const closeResetButton = document.querySelector("#closeResetButton");
  const confirmResetButton = document.querySelector("#confirmResetButton");
  const backdrop = document.querySelector("[data-close-reset]");

  if (resetSquadButton) resetSquadButton.addEventListener("click", openResetConfirm);
  if (closeResetButton) closeResetButton.addEventListener("click", closeResetConfirm);
  if (confirmResetButton) confirmResetButton.addEventListener("click", resetSquad);
  if (backdrop) backdrop.addEventListener("click", closeResetConfirm);

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && state.resetConfirmOpen) {
      closeResetConfirm();
    }
  });
}

function renderView() {
  document.querySelectorAll(".view").forEach((view) => {
    view.classList.toggle("is-active", view.dataset.view === state.currentView);
  });

  document.querySelectorAll(".nav-item[data-view-target]").forEach((button) => {
    button.classList.toggle("active", button.dataset.viewTarget === state.currentView);
  });

  const appShell = document.querySelector(".app-shell");
  if (appShell) {
    appShell.dataset.currentView = state.currentView;
  }
}

function setView(viewName, options = {}) {
  const validViews = ["home", "lineup", "board"];
  if (!validViews.includes(viewName)) viewName = "home";
  const viewExists = Boolean(document.querySelector(`.view[data-view="${viewName}"]`));
  if (!viewExists) return;

  state.currentView = viewName;
  renderView();

  if (options.scroll !== false) {
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({
      top: 0,
      behavior: prefersReducedMotion ? "auto" : "smooth"
    });
  }
}

function renderTransferStatusUI() {
  const isOpen = state.transferOpen;

  const statusTexts = document.querySelectorAll("[data-transfer-status-text]");
  statusTexts.forEach((el) => {
    el.textContent = isOpen ? t("transferOpen") : t("transferClosed");
  });

  const badges = document.querySelectorAll("[data-transfer-status-badge]");
  badges.forEach((badge) => {
    badge.textContent = isOpen ? t("open") : t("closed");
    badge.classList.toggle("is-locked", !isOpen);
  });

  const copies = document.querySelectorAll("[data-transfer-copy]");
  copies.forEach((copy) => {
    copy.textContent = isOpen
      ? t("transferCopyOpen")
      : t("transferCopyClosed");
  });

  const challengeMetric = document.querySelector("#challengeTransferMetric");
  if (challengeMetric) {
    challengeMetric.classList.toggle("is-locked", !isOpen);
  }
}

function getCurrentUserRank() {
  const rows = getLeaderboardRows();
  const current = rows.find((row) => row.isCurrent);
  return current ? current.rank : null;
}

function checkBonusWheelUnlock() {
  if (!state.matchSimulation.lastResult || state.bonusWheel.hasSpun) return;

  const currentRank = getCurrentUserRank();
  const unlocked = Boolean(currentRank) && currentRank <= state.bonusWheel.targetRank;

  state.bonusWheel.isUnlocked = unlocked;

  // If the user just earned the wheel, queue it. The match-result popup
  // takes priority — wheel opens only after that modal is dismissed.
  if (unlocked && !state.bonusWheel.hasSpun && !state.bonusWheel.lastReward) {
    if (state.matchResultModal.isOpen) {
      state.bonusWheel.pendingOpen = true;
      state.bonusWheel.isOpen = false;
    } else {
      state.bonusWheel.isOpen = true;
      state.bonusWheel.pendingOpen = false;
    }
  }
}

function openBonusWheelModal() {
  if (!state.bonusWheel.isUnlocked || state.bonusWheel.hasSpun) return;
  // Never stack on top of the match-result modal — queue instead.
  if (state.matchResultModal.isOpen) {
    state.bonusWheel.pendingOpen = true;
    state.bonusWheel.isOpen = false;
    return;
  }
  state.bonusWheel.isOpen = true;
  state.bonusWheel.pendingOpen = false;
  renderBonusWheelModal();
}

function closeBonusWheelModal() {
  state.bonusWheel.isOpen = false;
  renderBonusWheelModal();
}

function spinBonusWheel() {
  if (!state.bonusWheel.isUnlocked) {
    showFeedback(t("fbWheelLocked"));
    return;
  }
  if (state.bonusWheel.hasSpun) {
    showFeedback(t("fbWheelAlreadySpun"));
    return;
  }
  if (state.bonusWheel.isSpinning) return;

  // Pre-select reward so wheel physically stops on the correct segment
  const rewardIndex = Math.floor(Math.random() * wheelRewards.length);
  const reward = wheelRewards[rewardIndex];

  const segmentSize = 360 / wheelRewards.length; // 60° per segment
  const segmentCenter = rewardIndex * segmentSize; // visual center at rotation=0

  // 5–7 full spins + correction to land selected segment under top pointer
  const fullSpins = 5 + Math.floor(Math.random() * 3);
  const currentRotation = state.bonusWheel.rotation || 0;
  const targetRotation = currentRotation + fullSpins * 360 + (360 - segmentCenter);

  state.bonusWheel.isSpinning = true;
  state.bonusWheel.selectedRewardIndex = rewardIndex;
  state.bonusWheel.rotation = targetRotation;
  renderBonusWheelModal();

  window.setTimeout(() => {
    state.bonusWheel.isSpinning = false;
    state.bonusWheel.hasSpun = true;
    state.bonusWheel.lastReward = reward;

    if (reward.type === "points") {
      state.totalPoints += reward.points;
    } else if (reward.type === "squadPower") {
      state.squadRatingPointsBonus += reward.squadPower;
      syncSquadStats();
    }

    renderAll();

    let spinFeedback;
    if (reward.type === "points" && reward.points > 0) {
      spinFeedback = t("fbWheelPoints", getWheelRewardLabel(reward));
    } else if (reward.type === "squadPower") {
      spinFeedback = t("fbWheelPower");
    } else {
      spinFeedback = t("fbWheelEmpty");
    }
    showFeedback(spinFeedback);
  }, 2400);
}

function renderBonusWheelModal() {
  const modal = document.querySelector("#bonusWheelModal");
  if (!modal) return;

  // Defensive: if a render slips through while match-result is open,
  // force the wheel back into the queue. Two popups must never co-exist.
  if (state.bonusWheel.isOpen && state.matchResultModal.isOpen) {
    state.bonusWheel.pendingOpen = true;
    state.bonusWheel.isOpen = false;
  }

  const isOpen = state.bonusWheel.isOpen;
  modal.classList.toggle("is-open", isOpen);
  modal.setAttribute("aria-hidden", String(!isOpen));
  updateBodyModalState();

  if (!isOpen) return;

  const content = modal.querySelector("#bonusWheelContent");
  if (!content) return;

  const { isSpinning, hasSpun, lastReward } = state.bonusWheel;

  let stateClass;
  let statusText, resultHTML, buttonText, buttonDisabled, closeBtnHTML;

  if (hasSpun) {
    stateClass = "is-complete";
    if (lastReward && lastReward.type === "points" && lastReward.points > 0) {
      statusText = t("wheelCongrats", getWheelRewardLabel(lastReward));
      resultHTML = `<span class="bw-reward-label">${getWheelRewardLabel(lastReward)}</span>`;
    } else if (lastReward && lastReward.type === "squadPower") {
      statusText = t("wheelSquadPowerMsg", lastReward.squadPower);
      resultHTML = `<span class="bw-reward-label">${getWheelRewardLabel(lastReward)}</span>`;
    } else {
      statusText = t("wheelEmptyMsg");
      resultHTML = "";
    }
    buttonText     = t("wheelSpun");
    buttonDisabled = true;
    closeBtnHTML   = `
      <button class="bonus-wheel-close-btn" type="button" id="closeWheelAfterSpin">
        ${t("wheelSeeResult")}
      </button>`;
  } else if (isSpinning) {
    stateClass     = "is-spinning";
    statusText     = t("wheelStatusSpinning");
    resultHTML     = "";
    buttonText     = t("wheelSpinning");
    buttonDisabled = true;
    closeBtnHTML   = "";
  } else {
    stateClass     = "is-unlocked";
    statusText     = t("wheelStatusUnlocked");
    resultHTML     = "";
    buttonText     = t("wheelSpin");
    buttonDisabled = false;
    closeBtnHTML   = "";
  }

  content.innerHTML = `
    <div class="bw-body ${stateClass}" aria-live="polite">
      <div class="bonus-wheel-stage">
        <div class="bonus-wheel-pointer" aria-hidden="true"></div>
        <div class="bonus-wheel-visual" aria-hidden="true">
          <span class="wheel-label label-0"><strong>+50</strong><small>${t("wheelLabelPoints")}</small></span>
          <span class="wheel-label label-1"><strong>+75</strong><small>${t("wheelLabelPoints")}</small></span>
          <span class="wheel-label label-2"><strong>+100</strong><small>${t("wheelLabelPoints")}</small></span>
          <span class="wheel-label label-3"><strong>+150</strong><small>${t("wheelLabelPoints")}</small></span>
          <span class="wheel-label label-4"><strong>+10</strong><small>${t("wheelLabelPower")}</small></span>
          <span class="wheel-label label-5"><strong>0</strong><small>${t("wheelLabelNone")}</small></span>
          <span class="bonus-wheel-core"></span>
        </div>
      </div>

      <div class="bonus-wheel-result">
        <p>${statusText}</p>
        ${resultHTML}
      </div>

      <button
        class="bonus-wheel-button"
        type="button"
        id="spinWheelButton"
        ${buttonDisabled ? "disabled" : ""}
        aria-disabled="${buttonDisabled}"
      >${buttonText}</button>

      ${closeBtnHTML}

      <p class="bonus-wheel-disclaimer">${t("wheelDisclaimer")}</p>
    </div>
  `;

  const spinButton = content.querySelector("#spinWheelButton");
  if (spinButton && !buttonDisabled) {
    spinButton.addEventListener("click", spinBonusWheel);
  }

  const closeAfterSpin = content.querySelector("#closeWheelAfterSpin");
  if (closeAfterSpin) {
    closeAfterSpin.addEventListener("click", closeBonusWheelModal);
  }

  // Drive the CSS transition via --wheel-rotation custom property
  const wheelEl = content.querySelector(".bonus-wheel-visual");
  if (wheelEl) {
    if (isSpinning) {
      // Double-rAF: let browser paint rotate(0deg) first, then trigger transition
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (wheelEl.isConnected) {
            wheelEl.style.setProperty("--wheel-rotation", `${state.bonusWheel.rotation}deg`);
          }
        });
      });
    } else {
      // Snap to final position without transition (is-spinning class is gone)
      wheelEl.style.setProperty("--wheel-rotation", `${state.bonusWheel.rotation || 0}deg`);
    }
  }

  window.requestAnimationFrame(() => {
    if (!hasSpun && !isSpinning) {
      const spinBtn = modal.querySelector("#spinWheelButton");
      if (spinBtn) spinBtn.focus();
    }
  });
}

// ── Single source of truth for body modal-open class ────────
// Every modal render and close function must call updateBodyModalState()
// (directly or via renderAll) instead of touching body.classList itself.
// This guarantees scroll lock stays correct even when one modal closes
// while another is opening (e.g. Match Result → Bonus Wheel transition).
function isAnyModalOpen() {
  return Boolean(
    state.activePicker.isOpen
      || state.resetConfirmOpen
      || state.rulesModalOpen
      || state.bonusWheel.isOpen
      || state.matchResultModal.isOpen
  );
}

function updateBodyModalState() {
  document.body.classList.toggle("modal-open", isAnyModalOpen());
}

function closeMatchResultModal() {
  state.matchResultModal.isOpen = false;

  // Consume queued bonus wheel: only open if still unlocked and never spun.
  if (
    state.bonusWheel.pendingOpen
    && state.bonusWheel.isUnlocked
    && !state.bonusWheel.hasSpun
  ) {
    state.bonusWheel.isOpen = true;
    state.bonusWheel.pendingOpen = false;
  }

  renderAll();
}

function renderMatchResultModal() {
  const modal = document.querySelector("#matchResultModal");
  if (!modal) return;

  const isOpen = state.matchResultModal.isOpen;
  modal.classList.toggle("is-open", isOpen);
  modal.setAttribute("aria-hidden", String(!isOpen));
  updateBodyModalState();

  if (!isOpen) return;

  const content = modal.querySelector("#matchResultContent");
  if (!content) return;

  const result = state.matchSimulation.lastResult;
  if (!result) {
    // Guard: no result yet — close silently
    state.matchResultModal.isOpen = false;
    modal.classList.remove("is-open");
    return;
  }

  // Use snapshotted value from result so history items stay accurate.
  const vaultPoints   = result.investmentBonusPoints || 0;
  const grandTotal    = state.totalPoints;
  const vaultRowClass = `match-breakdown-item is-vault${vaultPoints === 0 ? " is-zero" : ""}`;
  const vaultDisplay  = `+${formatPoints(vaultPoints)}`;
  const vaultSubtext  = vaultPoints > 0 ? t("cashVaultBonusDesc") : t("noInvestment");

  const boosterNames = (result.boosterPlayers && result.boosterPlayers.length > 0)
    ? result.boosterPlayers.map((p) => `${p.name} +${p.boostPoints}`).join(" · ")
    : null;
  const boosterSubtext = boosterNames || t("boosterNone");

  // Wheel reward row — only render if the wheel was spun this round.
  const wheelReward = state.bonusWheel.lastReward;
  const wheelRowHTML = (state.bonusWheel.hasSpun && wheelReward)
    ? (() => {
        if (wheelReward.type === "points" && wheelReward.points > 0) {
          return `
            <article class="match-breakdown-item is-wheel">
              <div>
                <strong>${t("wheelBonus")}</strong>
                <span>${t("wheelBonusDesc")}</span>
              </div>
              <b>+${formatPoints(wheelReward.points)}</b>
            </article>`;
        }
        if (wheelReward.type === "squadPower") {
          return `
            <article class="match-breakdown-item is-wheel">
              <div>
                <strong>${t("wheelBonus")}</strong>
                <span>${t("wheelBonusSquadPowerDesc", wheelReward.squadPower)}</span>
              </div>
              <b>+0</b>
            </article>`;
        }
        // empty / 0-points
        return `
          <article class="match-breakdown-item is-wheel is-zero">
            <div>
              <strong>${t("wheelBonus")}</strong>
              <span>${t("wheelBonusEmpty")}</span>
            </div>
            <b>+0</b>
          </article>`;
      })()
    : "";

  const noteHTML = vaultPoints > 0
    ? `<p class="match-result-note">${t("vaultNoteResult")}</p>`
    : "";

  content.innerHTML = `
    <div class="match-result-hero">
      <div class="match-result-orb">
        <div class="match-result-trophy"></div>
      </div>
      <span class="section-kicker">${t("matchResultKicker")}</span>
      <h2 id="matchResultHeading">${t("matchFinished")}</h2>
      <p>${t("matchResultHeroCopy")}</p>
    </div>

    <div class="match-breakdown-list">
      <article class="match-breakdown-item">
        <div>
          <strong>${t("basePointsLabel")}</strong>
          <span>${t("basePointsDesc")}</span>
        </div>
        <b>+${formatPoints(result.basePoints)}</b>
      </article>

      <article class="match-breakdown-item is-booster${(result.boosterPoints || 0) === 0 ? " is-zero" : ""}">
        <div>
          <strong>${t("boosterPointsLabel")}</strong>
          <span>${boosterSubtext}</span>
        </div>
        <b>+${formatPoints(result.boosterPoints || 0)}</b>
      </article>

      <article class="${vaultRowClass}">
        <div>
          <strong>${t("cashVaultBonus")}</strong>
          <span>${vaultSubtext}</span>
        </div>
        <b>${vaultDisplay}</b>
      </article>
      ${wheelRowHTML}
    </div>

    <div class="match-breakdown-total">
      <span>${t("grandTotal")}</span>
      <strong>${formatPoints(grandTotal)}</strong>
      <small>${t("points")}</small>
    </div>

    <div class="match-result-rank-row">
      ${t("rankAdvanceText", result.rankChange)}
    </div>

    ${noteHTML}

    <div class="match-result-cta">
      <button class="match-result-board-btn" type="button" id="matchResultBoardBtn">
        ${t("viewOnBoard")}
      </button>
      <button class="match-result-close-btn" type="button" id="matchResultCloseBtn">
        ${t("close")}
      </button>
    </div>
  `;

  const boardBtn = content.querySelector("#matchResultBoardBtn");
  if (boardBtn) {
    boardBtn.addEventListener("click", () => {
      // Navigate first so the queued bonus wheel (if any) pops on the
      // board view, not on the lineup view the user is leaving.
      setView("board");
      closeMatchResultModal();
    });
  }

  const closeBtn = content.querySelector("#matchResultCloseBtn");
  if (closeBtn) {
    closeBtn.addEventListener("click", closeMatchResultModal);
  }

  window.requestAnimationFrame(() => {
    const focusTarget = modal.querySelector("#matchResultBoardBtn");
    if (focusTarget) focusTarget.focus();
  });
}

function renderAll() {
  renderTranslations();
  renderLanguageSwitcher();
  renderStats();
  renderCashVault();
  renderSquadProgress();
  renderPitch();
  renderBench();
  renderMatchPanel();
  renderMatchResultModal();
  renderBonusWheelModal();
  renderScoutList();
  renderPickerModal();
  renderResetConfirm();
  renderRulesModal();
  renderBoard();
  renderTransferStatusUI();
  renderView();
  // Belt-and-suspenders: final sync after the full pipeline runs.
  // Guarantees scroll lock matches state regardless of render order.
  updateBodyModalState();
}

function bindFormationButtons() {
  document.querySelectorAll(".formation-chip").forEach((button) => {
    button.addEventListener("click", () => {
      const nextFormation = button.dataset.formation;
      if (!formationLayouts[nextFormation]) return;

      document.querySelectorAll(".formation-chip").forEach((item) => {
        item.classList.toggle("active", item === button);
      });

      state.selectedFormation = nextFormation;
      const result = rebuildLineupSlots();
      renderAll();

      if (result.refunded.length) {
        const names = result.refunded.map((player) => player.name).join(", ");
        showFeedback(t("fbFormationRefund", names));
        return;
      }

      if (result.moved.length) {
        const names = result.moved.map((player) => player.name).join(", ");
        showFeedback(t("fbFormationBench", names));
        return;
      }

      showFeedback(t("fbFormationChosen", state.selectedFormation));
    });
  });
}

function bindHeroButton() {
  const buildTeamButton = document.querySelector("#buildTeamButton");
  if (!buildTeamButton) return;

  buildTeamButton.addEventListener("click", () => {
    setView("lineup");
  });
}

function bindMatchButton() {
  const playMatchButton = document.querySelector("#playMatchButton");
  if (!playMatchButton) return;

  playMatchButton.addEventListener("click", () => {
    playDemoMatch();
  });
}

function bindPickerControls() {
  const closeButton = document.querySelector("#closePickerButton");
  const backdrop = document.querySelector("[data-close-picker]");

  if (closeButton) {
    closeButton.addEventListener("click", () => {
      closePositionPicker();
    });
  }

  if (backdrop) {
    backdrop.addEventListener("click", () => {
      closePositionPicker();
    });
  }

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && state.activePicker.isOpen) {
      closePositionPicker();
    }
  });
}

function bindNavButtons() {
  document.querySelectorAll("[data-view-target]").forEach((button) => {
    button.addEventListener("click", () => {
      const viewName = button.dataset.viewTarget;
      if (!viewName) return;
      setView(viewName);
    });
  });
}

function shuffleArray(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function autoBuildSquad() {
  if (!state.transferOpen) {
    showFeedback(t("fbTransferClosed"));
    return;
  }

  // Yatırım miktarını koru — auto-build sadece kadroyu sıfırlar,
  // Ana Kasa demo yatırımı ve puan bonusu korunur.
  const savedInvestment      = state.demoInvestmentAmount  || 0;
  const savedInvestmentBonus = state.investmentBonusPoints || 0;

  state.balance = 1000000 + savedInvestment; // başlangıç bakiyesi + yatırım
  state.selectedPlayers = [];
  state.lineupSlots = {};
  state.benchSlots = {
    "bench-1": null, "bench-2": null, "bench-3": null,
    "bench-4": null, "bench-5": null
  };
  state.totalPoints = savedInvestmentBonus; // yatırım bonusu puanı sıfırlanmaz
  state.squadRatingPointsBonus = 0;
  state.matchSimulation.isPlayed = false;
  state.matchSimulation.isProcessing = false;
  state.matchSimulation.lastResult = null;
  state.matchSimulation.history = [];
  state.matchSimulation.readyFeedbackShown = false;
  state.transferOpen = true;
  state.bonusWheel.isUnlocked = false;
  state.bonusWheel.isOpen = false;
  state.bonusWheel.isSpinning = false;
  state.bonusWheel.hasSpun = false;
  state.bonusWheel.lastReward = null;
  state.bonusWheel.selectedRewardIndex = null;
  state.bonusWheel.rotation = 0;
  state.bonusWheel.pendingOpen = false;
  state.demoInvestmentAmount  = savedInvestment;      // korundu
  state.investmentBonusPoints = savedInvestmentBonus; // korundu
  state.matchResultModal.isOpen = false;

  const usedIds = new Set();
  const layout = getCurrentLayout();

  // Fill lineup slots — random pick within position, respecting balance
  layout.forEach((slotData) => {
    const pool = shuffleArray(
      demoPlayers.filter(
        (p) => p.position === slotData.position && !usedIds.has(p.id) && p.price <= state.balance
      )
    );
    if (!pool.length) return;
    const player = pool[0];
    state.lineupSlots[slotData.id] = player.id;
    state.selectedPlayers.push(player.id);
    state.balance -= player.price;
    usedIds.add(player.id);
  });

  // Fill bench slots — random from remaining affordable players
  const benchPool = shuffleArray(
    demoPlayers.filter((p) => !usedIds.has(p.id))
  );
  Object.keys(state.benchSlots).forEach((benchId) => {
    const candidate = benchPool.find((p) => !usedIds.has(p.id) && p.price <= state.balance);
    if (!candidate) return;
    state.benchSlots[benchId] = candidate.id;
    state.selectedPlayers.push(candidate.id);
    state.balance -= candidate.price;
    usedIds.add(candidate.id);
  });

  syncSquadStats();
  renderAll();
  showFeedback(t("fbAutoBuilt"));
}

function renderCashVault() {
  const balanceEl = document.querySelector("#cashVaultBalance");
  if (balanceEl) balanceEl.textContent = formatMoney(state.balance);

  const investedEl = document.querySelector("#cashVaultInvested");
  if (investedEl) {
    investedEl.textContent = state.demoInvestmentAmount > 0
      ? `+${formatMoney(state.demoInvestmentAmount)}`
      : t("noInvestmentYet");
  }

  const bonusPtsEl = document.querySelector("#cashVaultBonusPts");
  if (bonusPtsEl) {
    bonusPtsEl.textContent = state.investmentBonusPoints > 0
      ? `+${formatPoints(state.investmentBonusPoints)} ${t("bonusPointsLabel")}`
      : "—";
  }

  // Lock investment buttons once transfer is closed (match has been played).
  // Prevents post-match snapshot drift and unlimited point farming.
  const locked = !state.transferOpen;
  const vaultCard = document.querySelector(".cash-vault-card");
  if (vaultCard) vaultCard.classList.toggle("is-locked", locked);

  const investButtons = document.querySelectorAll("[data-investment-amount]");
  investButtons.forEach((btn) => {
    btn.disabled = locked;
    btn.setAttribute("aria-disabled", String(locked));
  });

  const noteEl = document.querySelector(".cash-vault-note");
  if (noteEl) {
    noteEl.textContent = locked
      ? t("vaultLockedNote")
      : t("vaultNote");
  }
}

function applyDemoInvestment(amount) {
  if (!amount || amount <= 0) return;
  if (!state.transferOpen) {
    showFeedback(t("fbVaultClosed"));
    return;
  }
  const bonusPoints = Math.round(amount / 1000);

  state.balance             += amount;
  state.demoInvestmentAmount += amount;
  state.investmentBonusPoints += bonusPoints;
  // NOT: totalPoints burada artırılmaz — calculateMatchResult() zaten
  // investmentBonusPoints'i maç puanına dahil ediyor (çift sayım önlenir).

  renderAll();

  const amountLabel = formatMoney(amount).replace("$", "").replace(",", ".");
  showFeedback(t("fbVaultAdded", amountLabel, formatPoints(bonusPoints)));
}

function bindCashVaultActions() {
  document.querySelectorAll("[data-investment-amount]").forEach((button) => {
    button.addEventListener("click", () => {
      const amount = Number(button.dataset.investmentAmount);
      applyDemoInvestment(amount);
    });
  });
}

function bindAutoSquadBuilder() {
  const btn = document.querySelector("#autoSquadButton");
  if (btn) btn.addEventListener("click", autoBuildSquad);
}

function bindBonusWheelModalControls() {
  const modal = document.querySelector("#bonusWheelModal");
  if (!modal) return;

  // Backdrop + header close button — both carry data-close-wheel
  modal.querySelectorAll("[data-close-wheel]").forEach((el) => {
    el.addEventListener("click", () => {
      if (!state.bonusWheel.isSpinning) closeBonusWheelModal();
    });
  });

  // Escape key — close only when not spinning
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && state.bonusWheel.isOpen && !state.bonusWheel.isSpinning) {
      closeBonusWheelModal();
    }
  });
}

function bindMatchResultModalControls() {
  const modal = document.querySelector("#matchResultModal");
  if (!modal) return;

  const backdrop = modal.querySelector("[data-close-match-result]");
  if (backdrop) {
    backdrop.addEventListener("click", closeMatchResultModal);
  }

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && state.matchResultModal.isOpen) {
      closeMatchResultModal();
    }
  });
}

function init() {
  rebuildLineupSlots();
  renderAll();
  bindHeroButton();
  bindMatchButton();
  bindFormationButtons();
  bindPickerControls();
  bindNavButtons();
  bindResetControls();
  bindRulesModalControls();
  bindBonusWheelModalControls();
  bindMatchResultModalControls();
  bindAutoSquadBuilder();
  bindCashVaultActions();
  bindLanguageSwitcher();
}

document.addEventListener("DOMContentLoaded", init);
